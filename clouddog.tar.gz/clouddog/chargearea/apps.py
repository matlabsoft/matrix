from django.apps import AppConfig


class ChargeareaConfig(AppConfig):
    name = 'chargearea'
