from django.db import models

# Create your models here.

class Chargearea(models.Model):
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    isdelete = models.BooleanField(default=False)
