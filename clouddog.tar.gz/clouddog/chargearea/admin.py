from django.contrib import admin
import chargearea.models

@admin.register(chargearea.models.Chargearea)
class ChargeareaAdmin(admin.ModelAdmin):
    list_display=("id", "name", "latitude", "logitude", "isdelete")
