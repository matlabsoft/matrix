from django.contrib import admin
import chargearea.models

def toJson_Chargearea(obj:chargearea.models.Chargearea):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("isdelete", obj.isdelete)

@admin.register(chargearea.models.Chargearea)
class ChargeareaAdmin(admin.ModelAdmin):
    list_display=("id", "latitude", "logitude", "isdelete")
