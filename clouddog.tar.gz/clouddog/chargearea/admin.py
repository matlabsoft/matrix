from django.contrib import admin
import chargearea.models

def toJson_Chargearea(obj:chargearea.models.Chargearea):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("createtime", obj.createtime)
    return ret

def build_Chargearea(datas:dict):
    data = chargearea.models.Chargearea()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("latitude") is not None:
        data.latitude = datas.get("latitude")
    if datas.get("logitude") is not None:
        data.logitude = datas.get("logitude")
    if datas.get("createtime") is not None:
        data.createtime = datas.get("createtime")
    return data

def selectNormalDatas_Chargearea(datas:dict):
    ret = {}
    if datas.get("latitude") is not None:
        ret.setdefault("latitude", datas.get("latitude"))
    if datas.get("logitude") is not None:
        ret.setdefault("logitude", datas.get("logitude"))
    if datas.get("createtime") is not None:
        ret.setdefault("createtime", datas.get("createtime"))
    return ret

@admin.register(chargearea.models.Chargearea)
class ChargeareaAdmin(admin.ModelAdmin):
    list_display=("id", "latitude", "logitude", "createtime")
