from django.http import HttpRequest
from const import errcode
from chargearea.admin import toJson_Chargearea, selectNormalDatas_Chargearea, build_Chargearea
from chargearea.models import Chargearea, getAreas
import json
import logging
from utils.response import make_responce, parseInputParameters
from utils.resourcelock import taskdoglock
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
logger = logging.getLogger('chargearea')


def getAreasJson(id=None, latitude=None, logitude=None):
    datas = getAreas(id, latitude, logitude)
    if datas is None:
        return None
    if type(datas) == Chargearea:
        return toJson_Chargearea(datas)
    return [toJson_Chargearea(data) for data in datas]


@csrf_exempt
def chargearea(request: HttpRequest):
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    if request.method == "GET":
        id = datas.get("id")
        latitude = datas.get("latitude")
        logitude = datas.get("logitude")
        return make_responce(errcode.SUCCESS, datas=getAreasJson(id, latitude, logitude))
    elif request.method == "POST":
        normaldatas = selectNormalDatas_Chargearea(datas)
        Chargearea.objects.update_or_create(id=datas.get("id"), defaults=normaldatas)
        area = getAreas(id=datas.get("id"), latitude=normaldatas.get("latitude"), logitude=normaldatas.get("logitude"))
        return make_responce(errcode.SUCCESS, datas=toJson_Chargearea(area))
    elif request.method == "PUT":
        id = datas.get("id")
        if id is not None:
            normaldatas = selectNormalDatas_Chargearea(datas)
            Chargearea.objects.filter(id=id).update(**normaldatas)
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    elif request.method == "DELETE":
        id = datas.get("id")
        if id is not None:
            Chargearea.objects.filter(id=id).delete()
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
