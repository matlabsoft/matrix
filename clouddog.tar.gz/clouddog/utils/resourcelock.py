from threading import Lock
from functools import wraps


taskdoglock = Lock()

def synctaskdogw(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        taskdoglock.acquire()
        try:
            return f(*args, **kwargs)
        finally:
            taskdoglock.release()
    return decorated

def synctaskdogr(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        taskdoglock.acquire()
        try:
            return f(*args, **kwargs)
        finally:
            taskdoglock.release()
    return decorated
