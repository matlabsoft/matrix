from django.http import JsonResponse
import json
import logging

logger = logging.getLogger('utils')

def make_responce(retcode = None, msg = "", datas = None):
    return JsonResponse({"retcode": retcode, "msg": msg, "data": datas})

def parseInputParameters(request):
    try:
        if not request.body:
            return parseHeadParameters(request)
        datas = json.loads(request.body)
        return datas
    except:
        return parseHeadParameters(request)

def parseHeadParameters(request):
    rawdatas = request.headers
    if request.method == "GET":
        rawdatas = request.GET
    datas = {}
    for k in rawdatas.keys():
        if k in ["id", "topn", "userid", "dogid", "maxline", "areaid"]:
            datas.setdefault(k, int(rawdatas.get(k)))
        elif k in ["latitude", "logitude", "remainpower", "money", "leftpowerofcar", "currentflow", "powerfee"]:
            datas.setdefault(k, float(rawdatas.get(k)))
        else:
            datas.setdefault(k, rawdatas.get(k))
    return datas

def json2SimpleLog(datas, MAX_STR_LEN=20, MAX_LIST_LEN=5):
    if type(datas) in [str, bytes]:
        if len(datas) > MAX_STR_LEN:
            return datas[:MAX_STR_LEN] + "..."
        return datas
    elif type(datas) in [list, tuple]:
        if len(datas) > MAX_LIST_LEN:
            return "[" + ",".join([json2SimpleLog(data, MAX_STR_LEN, MAX_LIST_LEN) for data in datas[:MAX_LIST_LEN]]) + ",...]"
        else:
            return "[" + ",".join([json2SimpleLog(data, MAX_STR_LEN, MAX_LIST_LEN) for data in datas]) + ",...]"
    return "%s"%datas
