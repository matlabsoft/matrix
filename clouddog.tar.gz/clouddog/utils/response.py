from django.http import JsonResponse

def make_responce(retcode = None, msg = "", datas = None):
    return JsonResponse({"retcode": retcode, "msg": msg, "data": datas})