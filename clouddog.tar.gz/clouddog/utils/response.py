from django.http import JsonResponse
import json
import logging

logger = logging.getLogger('utils')

def make_responce(retcode = None, msg = "", datas = None):
    return JsonResponse({"retcode": retcode, "msg": msg, "data": datas})

def parseInputParameters(request):
    try:
        datas = json.loads(request.body)
        return datas
    except:
        rawdatas = request.headers.keys()
        if request.method == "GET":
            rawdatas = request.GET
        datas = {}
        for k in rawdatas.keys():
            if k in ["id", "topn", "userid", "dogid", "maxline", "areaid"]:
                datas.setdefault(k, int(rawdatas.get(k)))
            elif k in ["latitude", "logitude", "remainpower", "money", "leftpowerofcar", "currentflow", "powerfee"]:
                datas.setdefault(k, float(rawdatas.get(k)))
            else:
                datas.setdefault(k, rawdatas.get(k))
        return datas
