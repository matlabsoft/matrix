from django.contrib import admin
import vehicle.models

@admin.register(vehicle.models.Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display=("id", "producername", "productname", "carnumber", "latitude", "logitude", "command", "isdelete")
