from django.contrib import admin
import vehicle.models

def toJson_Vehicle(obj:vehicle.models.Vehicle):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("producername", obj.producername)
    ret.setdefault("productname", obj.productname)
    ret.setdefault("carnumber", obj.carnumber)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("isdelete", obj.isdelete)
    return ret

def build_Vehicle(datas:dict):
    data = vehicle.models.Vehicle()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("producername") is not None:
        data.producername = datas.get("producername")
    if datas.get("productname") is not None:
        data.productname = datas.get("productname")
    if datas.get("carnumber") is not None:
        data.carnumber = datas.get("carnumber")
    if datas.get("latitude") is not None:
        data.latitude = datas.get("latitude")
    if datas.get("logitude") is not None:
        data.logitude = datas.get("logitude")
    if datas.get("isdelete") is not None:
        data.isdelete = datas.get("isdelete")
    return data

def selectNormalDatas_Vehicle(datas:dict):
    ret = {}
    if datas.get("producername") is not None:
        ret.setdefault("producername", datas.get("producername"))
    if datas.get("productname") is not None:
        ret.setdefault("productname", datas.get("productname"))
    if datas.get("latitude") is not None:
        ret.setdefault("latitude", datas.get("latitude"))
    if datas.get("logitude") is not None:
        ret.setdefault("logitude", datas.get("logitude"))
    if datas.get("isdelete") is not None:
        ret.setdefault("isdelete", datas.get("isdelete"))
    return ret

@admin.register(vehicle.models.Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display=("id", "producername", "productname", "carnumber", "latitude", "logitude", "isdelete")
