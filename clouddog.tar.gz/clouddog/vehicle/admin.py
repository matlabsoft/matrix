from django.contrib import admin
import vehicle.models

def toJson_Vehicle(obj:vehicle.models.Vehicle):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("producername", obj.producername)
    ret.setdefault("productname", obj.productname)
    ret.setdefault("carnumber", obj.carnumber)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("command", obj.command)
    ret.setdefault("isdelete", obj.isdelete)

@admin.register(vehicle.models.Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display=("id", "producername", "productname", "carnumber", "latitude", "logitude", "command", "isdelete")
