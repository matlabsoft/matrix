from django.db import models

# Create your models here.

class Vehicle(models.Model):
    producername = models.CharField(max_length=100, default="")
    productname = models.CharField(max_length=100, default="")
    carnumber = models.CharField(max_length=20, default="")
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    command = models.CharField(max_length=100, default="") #NULL, STARTASK, CANCELTASK, ONECLICKRETURN
    isdelete = models.BooleanField(default=False)
