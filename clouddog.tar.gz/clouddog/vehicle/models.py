from django.db import models

# Create your models here.

class Vehicle(models.Model):
    producername = models.CharField(max_length=100, default="")#汽车厂商
    productname = models.CharField(max_length=100, default="")#产品名
    typename = models.CharField(max_length=100, default="")#产品型号
    isdelete = models.BooleanField(default=False)
