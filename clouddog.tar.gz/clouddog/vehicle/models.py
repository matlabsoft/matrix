from django.db import models

# Create your models here.

class Vehicle(models.Model):
    id = models.BigAutoField(primary_key=True)
    producername = models.CharField(max_length=100, default="")
    productname = models.CharField(max_length=100, default="")
    carnumber = models.CharField(max_length=20, default="", unique=True)
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    command = models.CharField(max_length=100, default="") #NULL, STARTASK, CANCELTASK, ONECLICKRETURN
    isdelete = models.BooleanField(default=False)
