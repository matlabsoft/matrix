from django.db import models

import logging

# Create your models here.
logger = logging.getLogger("parkarea")


class Parkarea(models.Model):
    id = models.BigAutoField(primary_key=True)
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    createtime = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('latitude', 'logitude')


def getAreas(id=None, latitude=None, logitude=None):
    try:
        if id is not None:
            return Parkarea.objects.get(id=id)
        if latitude is not None and logitude is not None:
            return Parkarea.objects.get(latitude=latitude, logitude=logitude)
    except Parkarea.DoesNotExist:
        return None
    except:
        logger.error("getAreas(%s,%s,%s) catch except"%(id, latitude, logitude))
        return None
    return Parkarea.objects.all()
