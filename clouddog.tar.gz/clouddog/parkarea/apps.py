from django.apps import AppConfig


class ParkareaConfig(AppConfig):
    name = 'parkarea'
