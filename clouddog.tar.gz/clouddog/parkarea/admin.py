from django.contrib import admin
import parkarea.models

def toJson_Parkarea(obj:parkarea.models.Parkarea):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("createtime", obj.createtime)
    return ret

def build_Parkarea(datas:dict):
    data = parkarea.models.Parkarea()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("latitude") is not None:
        data.latitude = datas.get("latitude")
    if datas.get("logitude") is not None:
        data.logitude = datas.get("logitude")
    if datas.get("createtime") is not None:
        data.createtime = datas.get("createtime")
    return data

def selectNormalDatas_Parkarea(datas:dict):
    ret = {}
    if datas.get("latitude") is not None:
        ret.setdefault("latitude", datas.get("latitude"))
    if datas.get("logitude") is not None:
        ret.setdefault("logitude", datas.get("logitude"))
    if datas.get("createtime") is not None:
        ret.setdefault("createtime", datas.get("createtime"))
    return ret

@admin.register(parkarea.models.Parkarea)
class ParkareaAdmin(admin.ModelAdmin):
    list_display=("id", "latitude", "logitude", "createtime")
