from django.contrib import admin
import parkarea.models

def toJson_Parkarea(obj:parkarea.models.Parkarea):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("heading", obj.heading)
    ret.setdefault("name", obj.name)
    ret.setdefault("createtime", obj.createtime)
    return ret

def build_Parkarea(datas:dict):
    data = parkarea.models.Parkarea()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("latitude") is not None:
        data.latitude = datas.get("latitude")
    if datas.get("logitude") is not None:
        data.logitude = datas.get("logitude")
    if datas.get("heading") is not None:
        data.heading = datas.get("heading")
    if datas.get("name") is not None:
        data.name = datas.get("name")
    if datas.get("createtime") is not None:
        data.createtime = datas.get("createtime")
    return data

def selectNormalDatas_Parkarea(datas:dict):
    ret = {}
    if datas.get("latitude") is not None:
        ret.setdefault("latitude", datas.get("latitude"))
    if datas.get("logitude") is not None:
        ret.setdefault("logitude", datas.get("logitude"))
    if datas.get("heading") is not None:
        ret.setdefault("heading", datas.get("heading"))
    if datas.get("name") is not None:
        ret.setdefault("name", datas.get("name"))
    if datas.get("createtime") is not None:
        ret.setdefault("createtime", datas.get("createtime"))
    return ret

@admin.register(parkarea.models.Parkarea)
class ParkareaAdmin(admin.ModelAdmin):
    list_display=("id", "latitude", "logitude", "heading", "name", "createtime")
