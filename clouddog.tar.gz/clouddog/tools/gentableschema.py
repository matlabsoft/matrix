import os
from typing import List
import re

rootdir = os.path.join(os.path.normpath(os.path.dirname(__file__)), "..")


class Table:
    def __init__(self):
        self.module = ""
        self.name = ""
        self.attrs = []

    def __str__(self):
        return "%s" % self.__dict__

    def __repr__(self):
        return self.__str__()


def loadTables() -> List[Table]:
    ret = []
    for module in os.listdir(rootdir):
        mfile = os.path.join(rootdir, module, "models.py")
        if not os.path.exists(mfile):
            continue
        ret.extend(loadATables(module, mfile))
    return ret


def loadapps() -> List[str]:
    return [module for module in os.listdir(rootdir) if os.path.exists(os.path.join(rootdir, module, "models.py"))]


def loadATables(module, mfile: str) -> List[Table]:
    ret = []
    buff = open(mfile, "r", encoding="utf-8").read()
    table = None
    for aLine in buff.splitlines():
        fIter = re.search("class\s+(?P<name>[\w]+)\s*", aLine)
        if fIter is not None and aLine.find("models.Model") > 0:
            if table is not None:
                ret.append(table)
            table = Table()
            table.module = module
            table.name = fIter.group("name")
            continue
        if table is None:
            continue
        if aLine.find("=") <= 0:
            continue
        table.attrs.append(aLine.split("=")[0].strip())
    if table is not None:
        ret.append(table)
    return ret


if __name__ == '__main__':
    print(loadTables())
