from tools import gentableschema
from typing import List
import os


def genadmin(app, tables:List[gentableschema.Table]):
    filepath = os.path.join(gentableschema.rootdir, app, "admin.py")
    buff = "from django.contrib import admin\n"
    buff += "import %s.models\n"%app
    for aTable in tables:
        buff += "\n"
        buff += '''def toJson_%s(obj:%s.models.%s):\n'''%(aTable.name, app, aTable.name)
        buff += '''    ret = {}\n'''
        for attr in aTable.attrs:
            buff += '''    ret.setdefault("%s", obj.%s)\n'''%(attr, attr)

        buff += '''\n@admin.register(%s.models.%s)\n'''%(app, aTable.name)
        buff += '''class %sAdmin(admin.ModelAdmin):\n'''%aTable.name
        buff += """    list_display=(%s)\n"""%(", ".join(['''"%s"'''%attr for attr in aTable.attrs]))
    open(filepath, "w", encoding="utf-8").write(buff)

def genAdmins():
    apps = gentableschema.loadapps()

    for app in apps:
        tables = gentableschema.loadATables(app, os.path.join(gentableschema.rootdir, app, "models.py"))
        genadmin(app, tables)

if __name__ == '__main__':
    genAdmins()