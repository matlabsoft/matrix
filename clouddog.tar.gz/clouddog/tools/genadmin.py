from tools import gentableschema
from typing import List
import os


def genadmin(app, tables:List[gentableschema.Table]):
    filepath = os.path.join(gentableschema.rootdir, app, "admin.py")
    buff = "from django.contrib import admin\n"
    buff += "import %s.models\n"%app
    for aTable in tables:
        buff += "\n"
        buff += '''@admin.register(%s.models.%s)\n'''%(app, aTable.name)
        buff += '''class %sAdmin(admin.ModelAdmin):\n'''%aTable.name
        buff += """    list_display=("id", %s)\n"""%(", ".join(['''"%s"'''%attr for attr in aTable.attrs]))
    open(filepath, "w", encoding="utf-8").write(buff)

def genAdmins():
    apps = gentableschema.loadapps()

    for app in apps:
        tables = gentableschema.loadATables(app, os.path.join(gentableschema.rootdir, app, "models.py"))
        genadmin(app, tables)

if __name__ == '__main__':
    genAdmins()