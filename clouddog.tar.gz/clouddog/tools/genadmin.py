from tools import gentableschema
from typing import List
import os


def genadmin(app, tables:List[gentableschema.Table]):
    filepath = os.path.join(gentableschema.rootdir, app, "admin.py")
    buff = "from django.contrib import admin\n"
    buff += "import %s.models\n"%app
    for aTable in tables:
        buff += "\n"
        buff += '''def toJson_%s(obj:%s.models.%s):\n'''%(aTable.name, app, aTable.name)
        buff += '''    ret = {}\n'''
        for attr in aTable.attrs:
            if attr.foreignKey:
                buff += '''    ret.setdefault("%s", obj.%s.id)\n'''%(attr.name, attr.name)
            else:
                buff += '''    ret.setdefault("%s", obj.%s)\n''' % (attr.name, attr.name)
        buff += '''    return ret\n'''


        buff += '''\ndef build_%s(datas:dict):\n'''%(aTable.name)
        buff += '''    data = %s.models.%s()\n'''%(app, aTable.name)
        for attr in aTable.attrs:
            buff += '''    if datas.get("%s") is not None:\n''' % (attr.name)
            buff += '''        data.%s = datas.get("%s")\n''' % (attr.name, attr.name)
        buff += '''    return data\n'''


        buff += '''\ndef selectNormalDatas_%s(datas:dict):\n'''%aTable.name
        buff += '''    ret = {}\n'''
        for attr in aTable.attrs:
            if attr.ispkey or attr.isuniq:
                continue
            buff += '''    if datas.get("%s") is not None:\n'''%(attr.name)
            buff += '''        ret.setdefault("%s", datas.get("%s"))\n'''%(attr.name, attr.name)
        buff += '''    return ret\n'''


        buff += '''\n@admin.register(%s.models.%s)\n'''%(app, aTable.name)
        buff += '''class %sAdmin(admin.ModelAdmin):\n'''%aTable.name
        buff += """    list_display=(%s)\n"""%(", ".join(['''"%s"'''%attr.name for attr in aTable.attrs]))
    open(filepath, "w", encoding="utf-8").write(buff)

def genAdmins():
    apps = gentableschema.loadapps()

    for app in apps:
        tables = gentableschema.loadATables(app, os.path.join(gentableschema.rootdir, app, "models.py"))
        genadmin(app, tables)

if __name__ == '__main__':
    genAdmins()