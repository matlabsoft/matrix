from django.contrib import admin
import chargedog.models

def toJson_Chargedog(obj:chargedog.models.Chargedog):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("name", obj.name)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("remainpower", obj.remainpower)
    ret.setdefault("mainstatus", obj.mainstatus)
    ret.setdefault("workmode", obj.workmode)
    ret.setdefault("detailmsg", obj.detailmsg)
    ret.setdefault("isdelete", obj.isdelete)

@admin.register(chargedog.models.Chargedog)
class ChargedogAdmin(admin.ModelAdmin):
    list_display=("id", "name", "latitude", "logitude", "remainpower", "mainstatus", "workmode", "detailmsg", "isdelete")
