from django.contrib import admin
import chargedog.models

@admin.register(chargedog.models.Chargedog)
class ChargedogAdmin(admin.ModelAdmin):
    list_display=("id", "name", "latitude", "logitude", "remainpower", "mainstatus", "workmode", "detailmsg", "isdelete")
