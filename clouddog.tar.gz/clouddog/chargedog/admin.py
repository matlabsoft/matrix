from django.contrib import admin
import chargedog.models

def toJson_Chargedog(obj:chargedog.models.Chargedog):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("name", obj.name)
    ret.setdefault("dogtype", obj.dogtype)
    ret.setdefault("dogversion", obj.dogversion)
    ret.setdefault("latitude", obj.latitude)
    ret.setdefault("logitude", obj.logitude)
    ret.setdefault("remainpower", obj.remainpower)
    ret.setdefault("mainstatus", obj.mainstatus)
    ret.setdefault("workmode", obj.workmode)
    ret.setdefault("remotecontrol", obj.remotecontrol)
    ret.setdefault("command", obj.command)
    ret.setdefault("detailmsg", obj.detailmsg)
    return ret

def build_Chargedog(datas:dict):
    data = chargedog.models.Chargedog()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("name") is not None:
        data.name = datas.get("name")
    if datas.get("dogtype") is not None:
        data.dogtype = datas.get("dogtype")
    if datas.get("dogversion") is not None:
        data.dogversion = datas.get("dogversion")
    if datas.get("latitude") is not None:
        data.latitude = datas.get("latitude")
    if datas.get("logitude") is not None:
        data.logitude = datas.get("logitude")
    if datas.get("remainpower") is not None:
        data.remainpower = datas.get("remainpower")
    if datas.get("mainstatus") is not None:
        data.mainstatus = datas.get("mainstatus")
    if datas.get("workmode") is not None:
        data.workmode = datas.get("workmode")
    if datas.get("remotecontrol") is not None:
        data.remotecontrol = datas.get("remotecontrol")
    if datas.get("command") is not None:
        data.command = datas.get("command")
    if datas.get("detailmsg") is not None:
        data.detailmsg = datas.get("detailmsg")
    return data

def selectNormalDatas_Chargedog(datas:dict):
    ret = {}
    if datas.get("dogtype") is not None:
        ret.setdefault("dogtype", datas.get("dogtype"))
    if datas.get("dogversion") is not None:
        ret.setdefault("dogversion", datas.get("dogversion"))
    if datas.get("latitude") is not None:
        ret.setdefault("latitude", datas.get("latitude"))
    if datas.get("logitude") is not None:
        ret.setdefault("logitude", datas.get("logitude"))
    if datas.get("remainpower") is not None:
        ret.setdefault("remainpower", datas.get("remainpower"))
    if datas.get("mainstatus") is not None:
        ret.setdefault("mainstatus", datas.get("mainstatus"))
    if datas.get("workmode") is not None:
        ret.setdefault("workmode", datas.get("workmode"))
    if datas.get("remotecontrol") is not None:
        ret.setdefault("remotecontrol", datas.get("remotecontrol"))
    if datas.get("command") is not None:
        ret.setdefault("command", datas.get("command"))
    if datas.get("detailmsg") is not None:
        ret.setdefault("detailmsg", datas.get("detailmsg"))
    return ret

@admin.register(chargedog.models.Chargedog)
class ChargedogAdmin(admin.ModelAdmin):
    list_display=("id", "name", "dogtype", "dogversion", "latitude", "logitude", "remainpower", "mainstatus", "workmode", "remotecontrol", "command", "detailmsg")
