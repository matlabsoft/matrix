from django.db import models

CHARGE_WORK_MODE = (
    ('IDLE', "空闲模式"),
    ('CHARGE', "充电模式"),
)
class Chargedog(models.Model):
    name = models.CharField(max_length=100, default="")
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    remainpower = models.FloatField(default=0) #剩余电量
    mainmode = models.CharField(max_length=100, default="IDLE", choices=CHARGE_WORK_MODE)
    submode = models.CharField(max_length=100, default="")
    isdelete = models.BooleanField(default=False)

