from django.db import models

MAIN_STATUS_CHOICES = (
    ('IDLE', "Idle"),
    ('MANUAL', "Manual task"),
    ('TASK', "Tasking"),
    ('SUPPLYPOWER', "Supplementary power supply"),
    ('REMOTECONTROL', "Remote control by man"),
    ('FAULT', "Fault"),
)
WORK_MODE_CHOICES = (
    ('MANUAL','Manual task'), #MANUAL
    ('IDLE','Idle'), #IDLE
    ('MOVING','Moving'), #IDLE
    ('ACMODE','Ac power mode'), #TASK
    ('CHARING_IDLE','The charging pile mode, idle'), #TASK
    ('CHARING_CHARING','The charging pile mode, charging'), #TASK
    ('CHARING_CONNECTING','The charging pile mode, connecting'), #TASK
    ('CHARING_COMPLETE','The charging pile mode, complete'), #TASK
    ('CHARING_RUNNING','The charging pile mode, running'), #TASK
    ('DC_QUICKLY','Dc quickly'), #SUPPLYPOWER
    ('AC_SLOWLY','Dc slowly'), #SUPPLYPOWER
    ('POWER_SAVE','Dc slowly'), #SUPPLYPOWER
    ('REMOTECONTROL','Dc slowly'), #SUPPLYPOWER
    ('FAULT','fault'), #FAULT
)

class Chargedog(models.Model):
    name = models.CharField(max_length=100, default="")
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    remainpower = models.FloatField(default=0) #kwh
    mainstatus = models.CharField(max_length=100, default="IDLE", choices=MAIN_STATUS_CHOICES)
    workmode = models.CharField(max_length=100, default="")
    detailmsg = models.CharField(max_length=1000, default="")
    isdelete = models.BooleanField(default=False)

