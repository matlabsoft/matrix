from django.db import models
import logging

logger = logging.getLogger("chargedog")

MAIN_STATUS_IDLE = "IDLE"#空闲态
MAIN_STATUS_MANUAL = "MANUAL"#手动任务
MAIN_STATUS_TASK = "TASK"
MAIN_STATUS_SUPPLYPOWER = "SUPPLYPOWER"
MAIN_STATUS_REMOTECONTROL = "REMOTECONTROL"
MAIN_STATUS_FAULT = "FAULT"

MAIN_STATUS_CHOICES = (
    (MAIN_STATUS_IDLE, "Idle"),
    (MAIN_STATUS_MANUAL, "Manual task"),
    (MAIN_STATUS_TASK, "Tasking"),
    (MAIN_STATUS_SUPPLYPOWER, "Supplementary power supply"),
    (MAIN_STATUS_REMOTECONTROL, "Remote control by man"),
    (MAIN_STATUS_FAULT, "Fault"),
)
WORK_MODE_MANUAL = "MANUAL"
WORK_MODE_IDLE = "IDLE"
WORK_MODE_MOVING = "MOVING"
WORK_MODE_ACMODE = "ACMODE"
WORK_MODE_CHARING_IDLE = "CHARING_IDLE"
WORK_MODE_CHARING_CHARING = "CHARING_CHARING"
WORK_MODE_CHARING_CONNECTING = "CHARING_CONNECTING"
WORK_MODE_CHARING_COMPLETE = "CHARING_COMPLETE"
WORK_MODE_CHARING_RUNNING = "CHARING_RUNNING"
WORK_MODE_DC_QUICKLY = "DC_QUICKLY"
WORK_MODE_AC_SLOWLY = "AC_SLOWLY"
WORK_MODE_POWER_SAVE = "POWER_SAVE"
WORK_MODE_ENERGY_STORAGE_BATTERY_FAULT = "ENERGY_STORAGE_BATTERY_FAULT"
WORK_MODE_INTELLIGENT_SYSTEM_FAULT = "INTELLIGENT_SYSTEM_FAULT"
WORK_MODE_DCC_FAULT = "DCC_FAULT"
WORK_MODE_POWER_FAULT = "POWER_FAULT"

WORK_MODE_CHOICES = (
    (WORK_MODE_MANUAL, 'Manual task'),  # MANUAL
    (WORK_MODE_IDLE, 'Idle'),  # IDLE
    (WORK_MODE_MOVING, 'Moving'),  # IDLE
    (WORK_MODE_ACMODE, '交流电源模式'),  # TASK
    (WORK_MODE_CHARING_IDLE, '充电桩模式_待机中'),  # TASK
    (WORK_MODE_CHARING_CHARING, '充电桩模式_充电中'),  # TASK
    (WORK_MODE_CHARING_CONNECTING, '充电桩模式_连接中'),  # TASK
    (WORK_MODE_CHARING_COMPLETE, '充电桩模式_充电完成'),  # TASK
    (WORK_MODE_CHARING_RUNNING, '奔赴中'),  # TASK
    (WORK_MODE_DC_QUICKLY, '直流快充'),  # SUPPLYPOWER 电能补充
    (WORK_MODE_AC_SLOWLY, '交流慢充'),  # SUPPLYPOWER 电能补充
    (WORK_MODE_POWER_SAVE, '节能补电'),  # SUPPLYPOWER 电能补充
    (WORK_MODE_ENERGY_STORAGE_BATTERY_FAULT, '储能电池故障'),  #FAULT
    (WORK_MODE_INTELLIGENT_SYSTEM_FAULT, '智能系统故障'), #FAULT
    (WORK_MODE_DCC_FAULT, 'DCC故障'), #FAULT
    (WORK_MODE_POWER_FAULT, 'DCC故障'), #FAULT
    #还有更多的故障状态，HMI与PHONE之间协商
)


class Chargedog(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=100, default="Manka-1", unique=True)
    dogtype = models.CharField(max_length=100, default="Pythagoras")
    dogversion = models.CharField(max_length=100, default="V1.0")
    latitude = models.FloatField(default=0)
    logitude = models.FloatField(default=0)
    remainpower = models.FloatField(default=0)  # kwh #狗胡剩余电量
    mainstatus = models.CharField(max_length=100, default=MAIN_STATUS_IDLE)
    workmode = models.CharField(max_length=200, default=WORK_MODE_IDLE)
    remotecontrol = models.BooleanField(default=False)#遥控行驶
    command = models.CharField(max_length=100, default="") #NULL, STARTASK, CANCELTASK, ONECLICKRETURN
    detailmsg = models.CharField(max_length=1000, default="")


def getDogs(id=None, name=None):
    try:
        if id is not None:
            return Chargedog.objects.get(id=id)
        if name is not None:
            return Chargedog.objects.get(name=name)
    except Chargedog.DoesNotExist:
        return None
    except:
        logger.error("getDogs(%s,%s) catch except" % (id, name))
        return None
    return Chargedog.objects.all()

def linkAttrChanged_Chargedog(datas:dict, olddog:Chargedog):
    #联动更新detailmsg, 状态发生变化的时候，将detailmsg清空
    mainstatus = datas.get("mainstatus")
    workmode = datas.get("workmode")
    remotecontrol = datas.get("remotecontrol")
    detailmsg = datas.get("detailmsg")
    if detailmsg is None:
        if ((mainstatus is not None and mainstatus != olddog.mainstatus)
            or (workmode is not None and workmode != olddog.workmode)
            or (remotecontrol is not None and remotecontrol != olddog.remotecontrol)):
            datas.setdefault("detailmsg", "")

