from django.http import HttpRequest
from django.shortcuts import render
from const import errcode
from chargedog.admin import toJson_Chargedog, selectNormalDatas_Chargedog
from chargearea.admin import toJson_Chargearea
from chargedog.models import Chargedog, getDogs, linkAttrChanged_Chargedog
from task.admin import toJson_Task
from user.admin import toJson_User
from vehicle.admin import toJson_Vehicle
from task.models import getTasks
import json
import logging
import collections
from utils.response import make_responce, parseInputParameters
from django.views.decorators.csrf import csrf_exempt
from utils.resourcelock import synctaskdogr, synctaskdogw

# Create your views here.
logger = logging.getLogger('chargearea')


def getDogsJson(id=None, macaddr=None):
    datas = getDogs(id, macaddr)
    if datas is None:
        return None
    if type(datas) == Chargedog:
        return toJson_Chargedog(datas)
    return [toJson_Chargedog(data) for data in datas]

@synctaskdogr
def dodogget(datas):
    id = datas.get("id")
    macaddr = datas.get("macaddr")
    return make_responce(errcode.SUCCESS, datas=getDogsJson(id, macaddr))

@synctaskdogw
def dodogcreate(datas):
    normaldatas = selectNormalDatas_Chargedog(datas)
    Chargedog.objects.update_or_create(macaddr=datas.get("macaddr"), defaults=normaldatas)
    area = getDogs(macaddr=datas.get("macaddr"))
    return make_responce(errcode.SUCCESS, datas=toJson_Chargedog(area))

@synctaskdogw
def dodogmodify(datas):
    id = datas.get("id")
    if id is not None:
        dog = Chargedog.objects.get(id=id)
        linkAttrChanged_Chargedog(datas, dog)
        normaldatas = selectNormalDatas_Chargedog(datas)
        Chargedog.objects.filter(id=id).update(**normaldatas)
        return make_responce(errcode.SUCCESS)
    return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)

@synctaskdogw
def dodogdelete(datas):
    id = datas.get("id")
    if id is not None:
        Chargedog.objects.filter(id=id).delete()
        return make_responce(errcode.SUCCESS)
    return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)

@csrf_exempt
def chargedog(request: HttpRequest):
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    if request.method == "GET":
        return dodogget(datas)
    elif request.method == "POST":
        return dodogcreate(datas)
    elif request.method == "PUT":
        return dodogmodify(datas)
    elif request.method == "DELETE":
        return dodogdelete(datas)
    return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))

@csrf_exempt
def dogdetail(request: HttpRequest):
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
    return dodogdetailget(datas)

@synctaskdogr
def dodogdetailget(datas):
    id = datas.get("id")
    macaddr = datas.get("macaddr")
    if id is None and macaddr is None:
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    dog = getDogs(id, macaddr)
    if not dog:
        return make_responce(errcode.FAILED, errcode.DOG_MSG_NO_SUCH_DATA)
    retdatas = {"dog": toJson_Chargedog(dog)}
    reltasks = getTasks(dogid=dog.id, topN=1)
    retdatas.setdefault("task", None)
    retdatas.setdefault("area", None)
    retdatas.setdefault("user", None)
    retdatas.setdefault("vehicle", None)
    if reltasks:
        retdatas.setdefault("task", toJson_Task(reltasks[0]))
        retdatas.setdefault("area", toJson_Chargearea(reltasks[0].chargearea))
        retdatas.setdefault("user", toJson_User(reltasks[0].user))
        retdatas.setdefault("vehicle", toJson_Vehicle(reltasks[0].vehicle))
    logger.info("%s"%retdatas)
    return make_responce(errcode.SUCCESS, datas=retdatas)

@csrf_exempt
def showlogs(request):
    datas = parseInputParameters(request)
    maxLine = datas.get("maxline")
    if not maxLine:
        maxLine = 20
    if maxLine > 5000:
        maxLine = 5000
    filename = request.headers.get("filename")
    if not filename:
        filename = "app"
    lines = collections.deque([], maxLine)
    fd = open("/var/log/clouddog/%s.log"%filename, "r")
    while True:
        aLine = fd.readline()
        if aLine != "":
            lines.append(aLine)
        else:
            break
    return render(request, "log.html", {"lines": lines, "is_popup":False, "title":"Log"})

