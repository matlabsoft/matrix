from django.http import HttpRequest
from const import errcode
from chargedog.admin import toJson_Chargedog, selectNormalDatas_Chargedog
from chargedog.models import Chargedog, getDogs, linkAttrChanged_Chargedog
from task.admin import toJson_Task
from task.models import getTasks
import json
import logging
from utils.response import make_responce
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
logger = logging.getLogger('chargearea')


def getDogsJson(id=None, macaddr=None):
    datas = getDogs(id, macaddr)
    if datas is None:
        return None
    if type(datas) == Chargedog:
        return toJson_Chargedog(datas)
    return [toJson_Chargedog(data) for data in datas]

@csrf_exempt
def chargedog(request: HttpRequest):
    datas = json.loads(request.body)
    logger.info("%s"%datas);
    if request.method == "GET":
        id = datas.get("id")
        macaddr = datas.get("macaddr")
        return make_responce(errcode.SUCCESS, datas=getDogsJson(id, macaddr))
    elif request.method == "POST":
        normaldatas = selectNormalDatas_Chargedog(datas)
        Chargedog.objects.update_or_create(macaddr=datas.get("macaddr"), defaults=normaldatas)
        area = getDogs(macaddr=datas.get("macaddr"))
        return make_responce(errcode.SUCCESS, datas=toJson_Chargedog(area))
    elif request.method == "PUT":
        id = datas.get("id")
        if id is not None:
            dog = Chargedog.objects.get(id=id)
            linkAttrChanged_Chargedog(datas, dog)
            normaldatas = selectNormalDatas_Chargedog(datas)
            Chargedog.objects.filter(id=id).update(**normaldatas)
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    elif request.method == "DELETE":
        id = datas.get("id")
        if id is not None:
            Chargedog.objects.filter(id=id).delete()
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))

@csrf_exempt
def dogdetail(request: HttpRequest):
    datas = json.loads(request.body)
    logger.info("%s"%datas);
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
    id = datas.get("id")
    macaddr = datas.get("macaddr")
    if id is None and macaddr is None:
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    dog = getDogs(id, macaddr)
    if not dog:
        return make_responce(errcode.FAILED, errcode.DOG_MSG_NO_SUCH_DATA)
    retdatas = {"dog": toJson_Chargedog(dog)}
    reltasks = getTasks(dogid=dog.id, topN=1)
    if not reltasks:
        retdatas.setdefault("task", None)
    else:
        retdatas.setdefault("task", toJson_Task(reltasks[0]))
    return make_responce(errcode.SUCCESS, datas=retdatas)


