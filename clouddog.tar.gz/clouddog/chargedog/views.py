from django.http import HttpRequest
from const import errcode
from chargedog.admin import toJson_Chargedog, selectNormalDatas_Chargedog
from chargedog.models import Chargedog, getDogs, linkAttrChanged_Chargedog
import json
import logging
from utils.response import make_responce
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
logger = logging.getLogger('chargearea')


def getDogsJson(id=None, name=None):
    datas = getDogs(id, name)
    if datas is None:
        return None
    if type(datas) == Chargedog:
        return toJson_Chargedog(datas)
    return [toJson_Chargedog(data) for data in datas]

@csrf_exempt
def chargedog(request: HttpRequest):
    if request.method == "GET":
        datas = json.loads(request.body)
        id = datas.get("id")
        name = datas.get("name")
        return make_responce(errcode.SUCCESS, datas=getDogsJson(id, name))
    elif request.method == "POST":
        datas = json.loads(request.body)
        normaldatas = selectNormalDatas_Chargedog(datas)
        Chargedog.objects.update_or_create(name=datas.get("name"), defaults=normaldatas)
        area = getDogs(name=datas.get("name"))
        return make_responce(errcode.SUCCESS, datas=toJson_Chargedog(area))
    elif request.method == "PUT":
        datas = json.loads(request.body)
        id = datas.get("id")
        if id is not None:
            dog = Chargedog.objects.get(id=id)
            linkAttrChanged_Chargedog(datas, dog)
            normaldatas = selectNormalDatas_Chargedog(datas)
            Chargedog.objects.filter(id=id).update(**normaldatas)
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    elif request.method == "DELETE":
        datas = json.loads(request.body)
        id = datas.get("id")
        if id is not None:
            Chargedog.objects.filter(id=id).delete()
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
