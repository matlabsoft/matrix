from django.apps import AppConfig
from chargedog.models import Chargedog, MAIN_STATUS_IDLE
from task.models import Task, TASK_FINISH, TASK_CANCELED
import logging
from const import errcode

logger = logging.getLogger("chargedog")


class ChargedogConfig(AppConfig):
    name = 'chargedog'

def getDistance(olat, ologi, obj) ->float:
    return ((obj.latitude - olat) **2 + (obj.logitude - ologi)**2) ** 0.5

def getNearestAvaiableDog(latitude, logitude, needpower):
    useddogids = [data["chargedog__id"] for data in Task.objects.exclude(status=TASK_FINISH).exclude(status=TASK_CANCELED).values('chargedog__id')]
    logger.info("getNearestAvaiableDog useddogids=%s"%useddogids)

    existsdog = Chargedog.objects.filter(mainstatus=MAIN_STATUS_IDLE)

    avaiabledogs = [dog for dog in existsdog if dog.id not in useddogids]
    logger.info("getNearestAvaiableDog idle dogs=%s"%avaiabledogs)

    if not avaiabledogs:
        return None, errcode.TASKCREATE_MSG_NO_AVAIABLE_CHARGEDOG

    SAVE_POWER = 3.0
    #avaiabledogs = [dog for dog in avaiabledogs if dog.remainpower - needpower >= SAVE_POWER]
    avaiabledogs = [dog for dog in avaiabledogs if dog.remainpower > SAVE_POWER]
    logger.info("getNearestAvaiableDog enough power dogs=%s"%avaiabledogs)
    if not avaiabledogs:
        return None, errcode.TASKCREATE_MSG_TOO_MUCH_POWER_IS_REQUIRED

    for dog in avaiabledogs:
        dog._distance = getDistance(latitude, logitude, dog)

    #500m 0.5km
    MAX_DISTANCE = 0.00449
    avaiabledogs = [dog for dog in avaiabledogs if dog._distance < MAX_DISTANCE]
    logger.info("getNearestAvaiableDog <500m dogids=%s"%avaiabledogs)
    if not avaiabledogs:
        return None, errcode.TASKCREATE_MSG_NO_NEAR_AVAIABLE_CHARGEDOG

    avaiabledogs.sort(key=lambda dog: dog._distance)

    return avaiabledogs[0], ""
