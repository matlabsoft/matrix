from django.apps import AppConfig
from chargedog.models import Chargedog, MAIN_STATUS_IDLE
from task.models import Task, TASK_FINISH, TASK_CANCELED
import logging

logger = logging.getLogger("chargedog")


class ChargedogConfig(AppConfig):
    name = 'chargedog'

def getDistance(olat, ologi, obj) ->float:
    return ((obj.latitude - olat) **2 + (obj.logitude - ologi)**2) ** 0.5

def getNearestAvaiableDog(latitude, logitude):
    useddogids = [data["chargedog__id"] for data in Task.objects.exclude(status=TASK_FINISH).exclude(status=TASK_CANCELED).values('chargedog__id')]
    logger.info("getNearestAvaiableDog useddogids=%s"%useddogids)

    existsdog = Chargedog.objects.filter(mainstatus=MAIN_STATUS_IDLE)

    avaiabledogs = [dog for dog in existsdog if dog.id not in useddogids]

    for dog in avaiabledogs:
        dog._distance = getDistance(latitude, logitude, dog)
    avaiabledogs.sort(key=lambda dog: dog._distance)

    if not avaiabledogs:
        return None
    return avaiabledogs[0]
