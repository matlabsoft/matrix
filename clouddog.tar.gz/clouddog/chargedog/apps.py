from django.apps import AppConfig


class ChargedogConfig(AppConfig):
    name = 'chargedog'
