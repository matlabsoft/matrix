from django.contrib import admin
import task.models

@admin.register(task.models.Task)
class TaskAdmin(admin.ModelAdmin):
    list_display=("id", "user", "chargedog", "chargearea", "starttime")
