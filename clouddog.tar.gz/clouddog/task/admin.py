from django.contrib import admin
import task.models

def toJson_Task(obj:task.models.Task):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("user", obj.user.id)
    ret.setdefault("chargedog", obj.chargedog.id)
    ret.setdefault("chargearea", obj.chargearea.id)
    ret.setdefault("vehicle", obj.vehicle.id)
    ret.setdefault("starttime", obj.starttime)
    ret.setdefault("endtime", obj.endtime)
    ret.setdefault("status", obj.status)
    ret.setdefault("needpower", obj.needpower)
    ret.setdefault("haschargedpower", obj.haschargedpower)
    ret.setdefault("leftpowerofcar", obj.leftpowerofcar)
    ret.setdefault("leftchargetime", obj.leftchargetime)
    ret.setdefault("currentflow", obj.currentflow)
    ret.setdefault("powerfee", obj.powerfee)
    ret.setdefault("roadline", obj.roadline)
    return ret

def build_Task(datas:dict):
    data = task.models.Task()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("user") is not None:
        data.user = datas.get("user")
    if datas.get("chargedog") is not None:
        data.chargedog = datas.get("chargedog")
    if datas.get("chargearea") is not None:
        data.chargearea = datas.get("chargearea")
    if datas.get("vehicle") is not None:
        data.vehicle = datas.get("vehicle")
    if datas.get("starttime") is not None:
        data.starttime = datas.get("starttime")
    if datas.get("endtime") is not None:
        data.endtime = datas.get("endtime")
    if datas.get("status") is not None:
        data.status = datas.get("status")
    if datas.get("needpower") is not None:
        data.needpower = datas.get("needpower")
    if datas.get("haschargedpower") is not None:
        data.haschargedpower = datas.get("haschargedpower")
    if datas.get("leftpowerofcar") is not None:
        data.leftpowerofcar = datas.get("leftpowerofcar")
    if datas.get("leftchargetime") is not None:
        data.leftchargetime = datas.get("leftchargetime")
    if datas.get("currentflow") is not None:
        data.currentflow = datas.get("currentflow")
    if datas.get("powerfee") is not None:
        data.powerfee = datas.get("powerfee")
    if datas.get("roadline") is not None:
        data.roadline = datas.get("roadline")
    return data

def selectNormalDatas_Task(datas:dict):
    ret = {}
    if datas.get("user") is not None:
        ret.setdefault("user", datas.get("user"))
    if datas.get("chargedog") is not None:
        ret.setdefault("chargedog", datas.get("chargedog"))
    if datas.get("chargearea") is not None:
        ret.setdefault("chargearea", datas.get("chargearea"))
    if datas.get("vehicle") is not None:
        ret.setdefault("vehicle", datas.get("vehicle"))
    if datas.get("starttime") is not None:
        ret.setdefault("starttime", datas.get("starttime"))
    if datas.get("endtime") is not None:
        ret.setdefault("endtime", datas.get("endtime"))
    if datas.get("status") is not None:
        ret.setdefault("status", datas.get("status"))
    if datas.get("needpower") is not None:
        ret.setdefault("needpower", datas.get("needpower"))
    if datas.get("haschargedpower") is not None:
        ret.setdefault("haschargedpower", datas.get("haschargedpower"))
    if datas.get("leftpowerofcar") is not None:
        ret.setdefault("leftpowerofcar", datas.get("leftpowerofcar"))
    if datas.get("leftchargetime") is not None:
        ret.setdefault("leftchargetime", datas.get("leftchargetime"))
    if datas.get("currentflow") is not None:
        ret.setdefault("currentflow", datas.get("currentflow"))
    if datas.get("powerfee") is not None:
        ret.setdefault("powerfee", datas.get("powerfee"))
    if datas.get("roadline") is not None:
        ret.setdefault("roadline", datas.get("roadline"))
    return ret

@admin.register(task.models.Task)
class TaskAdmin(admin.ModelAdmin):
    list_display=("id", "user", "chargedog", "chargearea", "vehicle", "starttime", "endtime", "status", "needpower", "haschargedpower", "leftpowerofcar", "leftchargetime", "currentflow", "powerfee", "roadline")
