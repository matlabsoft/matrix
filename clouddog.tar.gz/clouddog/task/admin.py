from django.contrib import admin
import task.models

def toJson_Task(obj:task.models.Task):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("user", obj.user)
    ret.setdefault("chargedog", obj.chargedog)
    ret.setdefault("chargearea", obj.chargearea)
    ret.setdefault("starttime", obj.starttime)
    ret.setdefault("endtime", obj.endtime)
    ret.setdefault("needpower", obj.needpower)
    ret.setdefault("haschargedpower", obj.haschargedpower)
    ret.setdefault("leftpowerofcar", obj.leftpowerofcar)
    ret.setdefault("leftchargetime", obj.leftchargetime)
    ret.setdefault("currentflow", obj.currentflow)
    ret.setdefault("powerfee", obj.powerfee)
    ret.setdefault("roadline", obj.roadline)

@admin.register(task.models.Task)
class TaskAdmin(admin.ModelAdmin):
    list_display=("id", "user", "chargedog", "chargearea", "starttime", "endtime", "needpower", "haschargedpower", "leftpowerofcar", "leftchargetime", "currentflow", "powerfee", "roadline")
