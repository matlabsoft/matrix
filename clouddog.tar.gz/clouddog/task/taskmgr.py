from task.models import Task
from django.db import models
from threading import Thread, Lock

class Singleton(object):
    _instance = None

    def __new__(cls, *args, **kw):
        if not cls._instance:
            cls._instance = super(Singleton, cls).__new__(cls, *args, **kw)
        return cls._instance

class TaskIDGen(Singleton):
    def __init__(self):
        self.lastid = 0
        self.lock = Lock()
        self.hasflush = False

    def _flush_from_db(self):
        if self.hasflush:
            return
        self.lastid = Task.objects.all().aggregate(models.Max('id'))['id__max']
        if not self.lastid:
            self.lastid = 0
        self.hasflush = True
    def newId(self):
        self.lock.acquire()
        try:
            self._flush_from_db()
            self.lastid += 1
            return self.lastid
        finally:
            self.lock.release()

idgen = TaskIDGen()
