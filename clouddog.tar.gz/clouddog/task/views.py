from django.http import HttpRequest
from const import errcode
from task.admin import toJson_Task, selectNormalDatas_Task
from task.models import Task, getTasks, fillForeignkey_Task, cvtForeignkeyFilter_Task, TASK_CANCELED, TASK_FINISH
from task.models import tryFillForeignkey_Task
from task.taskmgr import idgen
from vehicle.admin import toJson_Vehicle
from chargedog.admin import toJson_Chargedog
from chargedog.apps import getNearestAvaiableDog
from chargearea.admin import toJson_Chargearea
from chargearea.models import Chargearea
from user.admin import toJson_User
import json
import logging
from utils.response import make_responce
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone

# Create your views here.
logger = logging.getLogger('chargearea')


def getTasksJson(id=None, userid=None, username=None, dogid=None, topN=1):
    datas = getTasks(id, userid, username, dogid, topN)
    if datas is None:
        return None
    if type(datas) == Task:
        return toJson_Task(datas)
    return [toJson_Task(data) for data in datas]

def linkAttrChanged_Task(datas:dict, oldtask:Task):
    # 在这里作属性间的联动处理
    status = datas.get("status")
    logger.info("input: %s, oldtask: %s"%(datas, toJson_Task(oldtask)))
    if (status == TASK_FINISH or status == TASK_CANCELED) and oldtask.status not in [TASK_FINISH, TASK_CANCELED]:
        #两个判断，避免重复扣费

        datas.setdefault("endtime", timezone.now())
        #同步更新用户胡money
        usedmoney = datas.get("powerfee")
        if usedmoney:
            oldtask.user.money -= usedmoney
        else:
            oldtask.user.money -= oldtask.powerfee
        oldtask.user.save()
    logger.info("input: %s, oldtask: %s"%(datas, toJson_Task(oldtask)))


@csrf_exempt
def task(request: HttpRequest):
    datas = json.loads(request.body)
    logger.info("%s"%datas);
    if request.method == "GET":
        id = datas.get("id")
        userid = datas.get("userid")
        username = datas.get("username")
        topn = datas.get("topn")
        dogid = datas.get("dogid")
        return make_responce(errcode.SUCCESS, datas=getTasksJson(id, userid, username, dogid, topn))
    elif request.method == "POST":
        normaldatas = selectNormalDatas_Task(datas)
        if not fillForeignkey_Task(normaldatas, datas):
            return make_responce(errcode.FAILED, msg=errcode.MSG_INPUT_PARAM_NOT_VALID)
        newtaskid = idgen.newId()
        normaldatas.setdefault("id", newtaskid)
        Task.objects.create(**normaldatas)
        try:
            task = Task.objects.get(id=newtaskid);
        except Task.DoesNotExist:
            return make_responce(errcode.FAILED, msg="Task does not exits")
        return make_responce(errcode.SUCCESS, datas=toJson_Task(task))
    elif request.method == "PUT":
        id = datas.get("id")
        if id is not None:
            oldtask = Task.objects.get(id=id)
            linkAttrChanged_Task(datas, oldtask)
            normaldatas = selectNormalDatas_Task(datas)
            Task.objects.filter(id=id).update(**normaldatas)
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    elif request.method == "DELETE":
        id = datas.get("id")
        if id is not None:
            Task.objects.filter(id=id).delete()
            return make_responce(errcode.SUCCESS)
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)
    return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))

@csrf_exempt
def trycreate(request: HttpRequest):
    datas = json.loads(request.body)
    logger.info("%s"%datas);
    if request.method != "POST":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
    normaldatas = selectNormalDatas_Task(datas)
    if not tryFillForeignkey_Task(normaldatas, datas):
        return make_responce(errcode.FAILED, msg=errcode.MSG_INPUT_PARAM_NOT_VALID)
    try:
        area = Chargearea.objects.get(id=datas.get("areaid"))
    except Chargearea.DoesNotExist:
        logger.info("area not exits. %s"%datas)
        return make_responce(errcode.FAILED, msg=errcode.MSG_INPUT_PARAM_NOT_VALID)
    dog = getNearestAvaiableDog(area.latitude, area.logitude)
    if dog is None:
        return make_responce(errcode.FAILED, msg=errcode.TASKCREATE_MSG_NO_AVAIABLE_CHARGEDOG)
    normaldatas.setdefault("chargedog_id", dog.id)
    newtaskid = idgen.newId()
    normaldatas.setdefault("id", newtaskid)
    Task.objects.create(**normaldatas)
    try:
        task = Task.objects.get(id=newtaskid);
    except Task.DoesNotExist:
        return make_responce(errcode.FAILED, msg="Task does not exits")
    return make_responce(errcode.SUCCESS, datas=toJson_Task(task))

@csrf_exempt
def taskdetail(request: HttpRequest):
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD % (request.method))
    datas = json.loads(request.body)
    id = datas.get("id")
    if id is None:
        return make_responce(errcode.FAILED, errcode.MSG_INPUT_PARAM_NOT_VALID)

    taskdata = Task.objects.get(id=id)

    return make_responce(errcode.SUCCESS, datas={"task":toJson_Task(taskdata),
                                                 "user":toJson_User(taskdata.user),
                                                 "chargedog":toJson_Chargedog(taskdata.chargedog),
                                                 "chargearea":toJson_Chargearea(taskdata.chargearea),
                                                 "vehicle":toJson_Vehicle(taskdata.vehicle)})

