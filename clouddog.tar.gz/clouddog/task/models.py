from django.db import models
import user.models
import chargedog.models
import chargearea.models
import vehicle.models
import logging

logger = logging.getLogger("task")

# Create your models here.

TASK_WAITING = "WAITTING"
TASK_INIT = "INIT"
TASK_MOVING = "MOVING"
TASK_CHARGING = "CHARING"
TASK_CONNECTING = "CONNECTING"
TASK_CANCELING = "CANCELING"
TASK_FINISH = "FINISH"
TASK_CANCELED = "CANCELED"

TASK_STATUS_CHOICES = (
    (TASK_WAITING, "Waitting ..."),
    (TASK_INIT, "Init ..."),
    (TASK_MOVING, "Moving ..."),
    (TASK_CHARGING, "Charging ..."),
    (TASK_CONNECTING, "Connecting ..."),
    (TASK_CANCELING, "Canceling ..."),
    (TASK_FINISH, "Finished ..."),
    (TASK_CANCELED, "Canceled ..."),
)

class Task(models.Model):
    id = models.BigIntegerField(primary_key=True)
    user =  models.ForeignKey(user.models.User, on_delete=models.CASCADE, null=False)
    chargedog = models.ForeignKey(chargedog.models.Chargedog, on_delete=models.CASCADE, null=False)
    chargearea = models.ForeignKey(chargearea.models.Chargearea, on_delete=models.CASCADE, null=False)
    vehicle = models.ForeignKey(vehicle.models.Vehicle, on_delete=models.CASCADE, null=False)
    starttime = models.DateTimeField(auto_now_add=True)
    endtime = models.DateTimeField(null=True)
    status = models.CharField(max_length=30, default=TASK_INIT)
    needpower = models.FloatField(default=0)#kwh
    haschargedpower = models.FloatField(default=0)#kwh
    leftpowerofcar = models.FloatField(default=-1)#kwh 小于0时代表不知道车子剩余多少电量
    leftchargetime = models.FloatField(default=0)#min
    currentflow = models.FloatField(default=0)#A(Ampere)
    powerfee = models.FloatField(default=0)#RMB
    roadline = models.TextField(default="[]")#json [[1,2],[1,3],...]

    class Meta:
        indexes = [
            models.Index(fields=['starttime'])
        ]

def tryFillForeignkey_Task(inoutDatas:dict, srcDatas:dict):
    userid = srcDatas.get("userid")
    username = srcDatas.get("username")
    areaid = srcDatas.get("areaid")
    vehicleid = srcDatas.get("vehicleid")
    if userid is not None:
        inoutDatas.setdefault("user_id", userid)
    else:
        if username is not None:
            inoutDatas.setdefault("user_username", username)
    if areaid is not None:
        inoutDatas.setdefault("chargearea_id", areaid)
    if vehicleid is not None:
        inoutDatas.setdefault("vehicle_id", vehicleid)
    if (userid is None and username is None) or areaid is None or vehicleid is None:
        return False
    return True


def fillForeignkey_Task(inoutDatas:dict, srcDatas:dict):
    userid = srcDatas.get("userid")
    username = srcDatas.get("username")
    dogname = srcDatas.get("dogname")
    dogid = srcDatas.get("dogid")
    areaid = srcDatas.get("areaid")
    vehicleid = srcDatas.get("vehicleid")
    if userid is not None:
        inoutDatas.setdefault("user_id", userid)
    else:
        if username is not None:
            inoutDatas.setdefault("user_username", username)
    if dogid is not None:
        inoutDatas.setdefault("chargedog_id", dogid)
    else:
        if dogname is not None:
            inoutDatas.setdefault("chargedog_name", dogname)
    if areaid is not None:
        inoutDatas.setdefault("chargearea_id", areaid)
    if vehicleid is not None:
        inoutDatas.setdefault("vehicle_id", vehicleid)
    if (userid is None and username is None) or (dogid is None and dogname is None) or areaid is None or vehicleid is None:
        return False
    return True

def cvtForeignkeyFilter_Task(srcDatas:dict):
    userid = srcDatas.get("userid")
    username = srcDatas.get("username")
    dogname = srcDatas.get("dogname")
    dogid = srcDatas.get("dogid")
    areaid = srcDatas.get("areid")
    vehicleid = srcDatas.get("vehicleid")
    ret = {}
    if userid:
        ret.setdefault("user__id", userid)
    else:
        if username:
            ret.setdefault("user__username", username)
    if dogid:
        ret.setdefault("chargedog__id", dogid)
    else:
        if dogname:
            ret.setdefault("chargedog__name", dogname)
    if areaid:
        ret.setdefault("chargearea__id", areaid)
    if vehicleid:
        ret.setdefault("vehicle__id", vehicleid)
    return ret

def getTasks(id= None, userid=None, username=None, dogid=None, topN=1):
    if not topN:
        topN = 100
    try:
        try:
            if id is not None:
                return Task.objects.get(id=id)
        except Task.DoesNotExist:
            return None
        queryCond = {}
        if userid is not None:
            queryCond.setdefault("user__id", userid)
        if username is not None:
            queryCond.setdefault("user__username", username)
        if dogid is not None:
            queryCond.setdefault("chargedog__id", dogid)
        if queryCond:
            return Task.objects.filter(**queryCond).order_by('-starttime')[:topN]
        return Task.objects.all().order_by('-starttime')[:topN]
    except:
        logger.error("getTasks(id=%s,userid=%s,username=%s,dogid=%s,topN=%s) catch except" % (id, userid, username, dogid, topN))
        return None
