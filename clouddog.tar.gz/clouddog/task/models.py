from django.db import models
import user.models
import chargedog.models
import chargearea.models

# Create your models here.

class Task(models.Model):
    user =  models.ForeignKey(user.models.User, on_delete=models.CASCADE, null=False)
    chargedog = models.ForeignKey(chargedog.models.Chargedog, on_delete=models.CASCADE, null=False)
    chargearea = models.ForeignKey(chargearea.models.Chargearea, on_delete=models.CASCADE, null=False)
    starttime = models.DateTimeField(auto_now=True)