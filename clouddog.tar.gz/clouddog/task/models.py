from django.db import models
import user.models
import chargedog.models
import chargearea.models

# Create your models here.

class Task(models.Model):
    id = models.BigAutoField(primary_key=True)
    user =  models.ForeignKey(user.models.User, on_delete=models.CASCADE, null=False)
    chargedog = models.ForeignKey(chargedog.models.Chargedog, on_delete=models.CASCADE, null=False)
    chargearea = models.ForeignKey(chargearea.models.Chargearea, on_delete=models.CASCADE, null=False)
    starttime = models.CharField(max_length=30, default="2019/10/14 14:30:30")
    endtime = models.CharField(max_length=30, default="")
    needpower = models.FloatField(default=0)#kwh
    haschargedpower = models.FloatField(default=0)#kwh
    leftpowerofcar = models.FloatField(default=0)#kwh
    leftchargetime = models.FloatField(default=0)#min
    currentflow = models.FloatField(default=0)#A(Ampere)
    powerfee = models.FloatField(default=0)#RMB
    roadline = models.TextField(default="[]")#json [[1,2],[1,3],...]
