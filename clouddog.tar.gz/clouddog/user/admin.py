from django.contrib import admin
import user.models

@admin.register(user.models.User)
class UserAdmin(admin.ModelAdmin):
    list_display=("id", "username", "userpwd", "money")

@admin.register(user.models.UserVehicle)
class UserVehicleAdmin(admin.ModelAdmin):
    list_display=("id", "user", "user")
