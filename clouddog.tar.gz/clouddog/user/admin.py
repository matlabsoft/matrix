from django.contrib import admin
import user.models

def toJson_User(obj:user.models.User):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("username", obj.username)
    ret.setdefault("money", obj.money)
    ret.setdefault("lastlogin", obj.lastlogin)
    ret.setdefault("createtime", obj.createtime)
    return ret

def build_User(datas:dict):
    data = user.models.User()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("username") is not None:
        data.username = datas.get("username")
    if datas.get("userpwd") is not None:
        data.userpwd = datas.get("userpwd")
    if datas.get("money") is not None:
        data.money = datas.get("money")
    if datas.get("lastlogin") is not None:
        data.lastlogin = datas.get("lastlogin")
    if datas.get("createtime") is not None:
        data.createtime = datas.get("createtime")
    return data

def selectNormalDatas_User(datas:dict):
    ret = {}
    if datas.get("userpwd") is not None:
        ret.setdefault("userpwd", datas.get("userpwd"))
    if datas.get("money") is not None:
        ret.setdefault("money", datas.get("money"))
    if datas.get("lastlogin") is not None:
        ret.setdefault("lastlogin", datas.get("lastlogin"))
    if datas.get("createtime") is not None:
        ret.setdefault("createtime", datas.get("createtime"))
    return ret

@admin.register(user.models.User)
class UserAdmin(admin.ModelAdmin):
    list_display=("id", "username", "userpwd", "money", "lastlogin", "createtime")

def toJson_UserVehicle(obj:user.models.UserVehicle):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("user", obj.user.id)
    ret.setdefault("vehicle", obj.vehicle.id)
    ret.setdefault("addtime", obj.addtime)
    return ret

def build_UserVehicle(datas:dict):
    data = user.models.UserVehicle()
    if datas.get("id") is not None:
        data.id = datas.get("id")
    if datas.get("user") is not None:
        data.user = datas.get("user")
    if datas.get("vehicle") is not None:
        data.vehicle = datas.get("vehicle")
    if datas.get("addtime") is not None:
        data.addtime = datas.get("addtime")
    return data

def selectNormalDatas_UserVehicle(datas:dict):
    ret = {}
    if datas.get("user") is not None:
        ret.setdefault("user", datas.get("user"))
    if datas.get("vehicle") is not None:
        ret.setdefault("vehicle", datas.get("vehicle"))
    if datas.get("addtime") is not None:
        ret.setdefault("addtime", datas.get("addtime"))
    return ret

@admin.register(user.models.UserVehicle)
class UserVehicleAdmin(admin.ModelAdmin):
    list_display=("id", "user", "vehicle", "addtime")
