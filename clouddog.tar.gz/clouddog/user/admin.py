from django.contrib import admin
import user.models

@admin.register(user.models.User)
class UserAdmin(admin.ModelAdmin):
    list_display=("id", "name", "password", "phonenumber", "vehicle", "isdelete")
