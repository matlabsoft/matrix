from django.contrib import admin
import user.models

def toJson_User(obj:user.models.User):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("username", obj.username)
    ret.setdefault("userpwd", obj.userpwd)
    ret.setdefault("money", obj.money)
    ret.setdefault("lastlogin", obj.lastlogin)
    ret.setdefault("createtime", obj.createtime)

@admin.register(user.models.User)
class UserAdmin(admin.ModelAdmin):
    list_display=("id", "username", "userpwd", "money", "lastlogin", "createtime")

def toJson_UserVehicle(obj:user.models.UserVehicle):
    ret = {}
    ret.setdefault("id", obj.id)
    ret.setdefault("user", obj.user)
    ret.setdefault("vehicle", obj.vehicle)

@admin.register(user.models.UserVehicle)
class UserVehicleAdmin(admin.ModelAdmin):
    list_display=("id", "user", "vehicle")
