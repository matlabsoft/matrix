from django.urls import path
import user.views


urlpatterns = [
    path('register/', user.views.userregister),
    path('changepwd/', user.views.userchangepwd),
    path('delete/', user.views.userdel),
    path('login/', user.views.userlogin),
    path('addvehicle/', user.views.addvehicle),
    path('delvehicle/', user.views.delvehicle),
    path('listvehicle/', user.views.listvehicle),
    path('get/', user.views.userget),
    path('put/', user.views.usermod),
    ]
