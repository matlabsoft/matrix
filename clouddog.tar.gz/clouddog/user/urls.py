from django.urls import path
import user.views


urlpatterns = [
    path('register/', user.views.userregister),
    path('changepwd/', user.views.userchangepwd),
    path('delete/', user.views.userdel),
    path('login/', user.views.userlogin),
    ]
