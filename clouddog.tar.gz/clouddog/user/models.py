from django.db import models
from django.contrib.auth.models import User as BaseUser
import vehicle.models
# Create your models here.

class User(models.Model):
    id = models.BigAutoField(primary_key=True)
    username = models.CharField(max_length=50, null=False, default="", unique=True)
    userpwd = models.CharField(max_length=100, null=False, default="")
    money = models.FloatField(default=0)
    lastlogin = models.DateTimeField(null=False)
    createtime = models.DateTimeField(null=False, auto_now_add=True)

class UserVehicle(models.Model):
    id = models.BigAutoField(primary_key=True)
    user =  models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    vehicle =  models.ForeignKey(vehicle.models.Vehicle, on_delete=models.CASCADE, null=False)
