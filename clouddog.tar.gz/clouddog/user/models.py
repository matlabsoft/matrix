from django.db import models
import vehicle.models
# Create your models here.

class User(models.Model):
    name = models.CharField(max_length=200, default="")
    password = models.CharField(max_length=100, default="")
    phonenumber = models.CharField(max_length=30, default="")
    vehicle = models.ForeignKey(vehicle.models.Vehicle, on_delete=models.SET_NULL, null=True)
    isdelete = models.BooleanField(default=False)
