from django.db import models
from django.contrib.auth.models import User as BaseUser
import vehicle.models
# Create your models here.

class User(models.Model):
    username = models.CharField(max_length=50, null=False, default="")
    userpwd = models.CharField(max_length=100, null=False, default="")
    money = models.FloatField(default=10000)

class UserVehicle(models.Model):
    user =  models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    user =  models.ForeignKey(vehicle.models.Vehicle, on_delete=models.CASCADE, null=False)
