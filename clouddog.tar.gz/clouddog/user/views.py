from django.http import JsonResponse, HttpRequest
from user.models import User, getUser
import user.admin
import vehicle.admin
from django.utils import timezone
from const import errcode
from user.models import UserVehicle
from vehicle.models import Vehicle
from chargearea.models import Chargearea
from chargedog.models import Chargedog
from task.models import Task
from vehicle.models import Vehicle
from chargedog.admin import toJson_Chargedog
from chargearea.admin import toJson_Chargearea

import task.models
import json
import logging
from django.views.decorators.csrf import csrf_exempt
from utils.response import make_responce, parseInputParameters


logger = logging.getLogger('user')


@csrf_exempt
def userlogin(request: HttpRequest):
    if request.method != "POST":
        return make_responce(errcode.LOGINFAILED, "Login failed %s" % request.method)
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    username = datas.get("username")
    userpwd = datas.get("userpwd")
    u = getUser(username=username)
    if u is None or u.userpwd != userpwd:
        return make_responce(errcode.LOGINFAILED)
    u.lastlogin = timezone.now()
    u.save()
    return make_responce(errcode.LOGINSUCCESS, datas=user.admin.toJson_User(u))


@csrf_exempt
def userregister(request: HttpRequest):
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    username = datas.get("username")
    userpwd = datas.get("userpwd")
    money = datas.get("money")
    if not money:
        money = 0
    if request.method == "POST":
        if User.objects.filter(username=username).count() > 0:
            return make_responce(errcode.USERADDFAILED, errcode.USERADD_THEREASAMEUSER)
        newuser = User.objects.create(username=username, userpwd=userpwd, money=money,
                                      lastlogin=timezone.now())
        return make_responce(errcode.USERADDSUCCESS, datas=user.admin.toJson_User(newuser))
    return make_responce(errcode.USERADDFAILED)


@csrf_exempt
def userchangepwd(request: HttpRequest):
    if request.method != "PUT":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    id = datas.get("id")
    username = datas.get("username")
    useroldpwd = datas.get("useroldpwd")
    userpwd = datas.get("userpwd")
    u = User.objects.get(username=username)
    if u is None or u.userpwd != useroldpwd:
        return make_responce(errcode.USERADDFAILED, errcode.USERCHPWD_MSG_OLDPWDNOTCORRECT)
    u.userpwd = userpwd
    u.save()
    datas = user.admin.toJson_User(u)
    datas.pop("userpwd")
    return make_responce(errcode.USERADDSUCCESS, datas=datas)

@csrf_exempt
def usermod(request: HttpRequest):
    if request.method != "PUT":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    id = datas.get("id")
    username = datas.get("username")
    keys = {}
    if id is not None:
        keys.setdefault("id", id)
    else:
        if username is not None:
            keys.setdefault("username", username)
    normaldatas = user.admin.selectNormalDatas_User(datas)
    User.objects.filter(**keys).update(**normaldatas)
    return make_responce(errcode.USERADDSUCCESS)


def getDistance(olat, ologi, obj) ->float:
    return ((obj.latitude - olat) **2 + (obj.logitude - ologi)**2) ** 0.5

def isInScope(olat, ologi, dis, obj) ->bool:
    return True

@csrf_exempt
def nearinfo(request: HttpRequest):
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    logger.info("%s"%datas);
    latitude = datas.get("latitude")
    logitude = datas.get("logitude")
    distance = datas.get("distance")

    areaobjs = Chargearea.objects.all()
    for obj in areaobjs:
        obj._tmp_dis = getDistance(latitude, logitude, obj)

    dogobjs = Chargedog.objects.all()
    for obj in dogobjs:
        obj._tmp_dis = getDistance(latitude, logitude, obj)

    areas = [toJson_Chargearea(obj) for obj in areaobjs if obj._tmp_dis < distance]
    dogs = [toJson_Chargedog(obj) for obj in dogobjs if obj._tmp_dis < distance]

    return make_responce(errcode.USERADDSUCCESS, datas={"areas":areas, "dogs":dogs})

@csrf_exempt
def clearall(request: HttpRequest):
    if request.method != "DELETE":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    Chargedog.objects.all().delete()
    User.objects.all().delete()
    Chargearea.objects.all().delete()
    Task.objects.all().delete()
    UserVehicle.objects.all().delete()
    Vehicle.objects.all().delete()
    return make_responce(errcode.SUCCESS)

@csrf_exempt
def userget(request: HttpRequest):
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    id = datas.get("id")
    if id is not None:
        u = User.objects.get(id=id)
    else:
        u = User.objects.get(username=datas.get("username"))
    datas = user.admin.toJson_User(u)
    datas.pop("userpwd")
    return make_responce(errcode.USERADDSUCCESS, datas=datas)

@csrf_exempt
def userdel(request: HttpRequest):
    if request.method != "DELETE":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    id = datas.get("id")
    username = datas.get("username")
    logger.info("userdel id=%s username=%s" % (id, username))
    u = getUser(id, username)
    if u is None:
        return make_responce(errcode.USERDELSUCCESS, errcode.USERDEL_MSG_NOSUCHUSER)
    taskcount = task.models.Task.objects.filter(user=u).exclude(status=task.models.TASK_CANCELED).exclude(
        status=task.models.TASK_FINISH).count()
    if taskcount > 0:
        return make_responce(errcode.USERDELFAILED, errcode.USERDEL_MSG_THEREATASKRUNNING)
    if id is not None:
        User.objects.filter(id=id).delete()
    else:
        User.objects.filter(username=username).delete()
    return make_responce(errcode.USERDELSUCCESS)


def getVechicles(id=None, username=None):
    if id is None:
        id = User.objects.get(username=username).id
    datas = UserVehicle.objects.filter(user_id=id)
    return [vehicle.admin.toJson_Vehicle(data.vehicle) for data in datas]


@csrf_exempt
def addvehicle(request: HttpRequest):
    if request.method != "POST":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    username = datas.get("username")
    uid = datas.get("userid")
    u = getUser(id=uid, username=username)
    if u is None:
        return make_responce(errcode.USERADDVEHICLEFAILED, errcode.USERADDVEHICLE_MSG_USERNOTFOUND)
    carnumber = datas.get("carnumber")
    defaultdatas = vehicle.admin.selectNormalDatas_Vehicle(datas)
    v, created = Vehicle.objects.update_or_create(carnumber=carnumber, defaults=defaultdatas)
    logger.info("uid=%s vid=%s" % (u.id, v.id))
    UserVehicle.objects.update_or_create(user=u, vehicle=v)
    return make_responce(errcode.USERDELSUCCESS, datas=getVechicles(u.id))

@csrf_exempt
def delvehicle(request: HttpRequest):
    if request.method != "DELETE":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    logger.info("delvehicle %s"%datas)
    delCond = {}
    id = datas.get("id")
    username = datas.get("username")
    uid = datas.get("userid")
    if id is not None:
        delCond.setdefault("id", id)
    else:
        if uid is not None:
            delCond.setdefault("user__id", uid)
        else:
            if username is not None:
                delCond.setdefault("user__username", username)
        carnumber = datas.get("carnumber")
        carid = datas.get("carid")
        if carid is not None:
            delCond.setdefault("vehicle__id", carid)
        else:
            if carnumber is not None:
                delCond.setdefault("vehicle__carnumber", carnumber)
    UserVehicle.objects.filter(**delCond).delete()
    return make_responce(errcode.USERDELSUCCESS)


@csrf_exempt
def listvehicle(request: HttpRequest):
    if request.method != "GET":
        return make_responce(errcode.FAILED, errcode.MSG_NOT_SUPPORT_METHOD%request.method)
    datas = parseInputParameters(request)
    id = datas.get("id")
    username = datas.get("username")
    return make_responce(errcode.USERLISTVEHICLESUCCESS, datas=getVechicles(id, username))
