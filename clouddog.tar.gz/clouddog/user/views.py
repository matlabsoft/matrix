from django.http import JsonResponse, HttpRequest
from user.models import User
import user.admin
from django.utils import timezone
from const import errcode
from user.models import UserVehicle
from vehicle.models import Vehicle
import task.models
import json
import logging
from django.views.decorators.csrf import csrf_exempt

logger = logging.getLogger('user')


@csrf_exempt
def userlogin(request: HttpRequest):
    if request.method == "POST":
        return JsonResponse({"retcode": 1, "msg": "Login failed %s" % request.method, "data": {}})
    datas = json.loads(request.body)
    username = datas.get("username")
    userpwd = datas.get("userpwd")
    u = User.objects.get(username=username)
    if u is None or u.userpwd != userpwd:
        return JsonResponse({"retcode": errcode.LOGINFAIED, "msg": "", "data": {}})
    return JsonResponse({"retcode": errcode.LOGINSUCCESS, "msg": "", "data": user.admin.toJson_User(u)})


@csrf_exempt
def userregister(request: HttpRequest):
    datas = json.loads(request.body)
    username = datas.get("username")
    userpwd = datas.get("userpwd")
    money = datas.get("money")
    if not money:
        money = 0
    if request.method == "POST":
        if User.objects.filter(username=username).count() > 0:
            return JsonResponse({"retcode": errcode.USERADDFAILED, "msg": errcode.USERADD_THEREASAMEUSER, "data": {}})
        newuser = User.objects.create(username=username, userpwd=userpwd, money=money,
                                               lastlogin=timezone.now())
        return JsonResponse({"retcode": errcode.USERADDSUCCESS, "msg": "", "data": user.admin.toJson_User(newuser)})
    return JsonResponse({"retcode": errcode.USERADDFAILED, "msg": "", "data": {}})


@csrf_exempt
def userchangepwd(request: HttpRequest):
    datas = json.loads(request.body)
    id = datas.get("id")
    username = datas.get("username")
    useroldpwd = datas.get("useroldpwd")
    userpwd = datas.get("userpwd")
    u = User.objects.get(username=username)
    if u is None or u.userpwd != useroldpwd:
        return JsonResponse(
            {"retcode": errcode.USERADDFAILED, "msg": errcode.USERCHPWD_MSG_OLDPWDNOTCORRECT, "data": {}})
    u.userpwd = userpwd
    u.save()
    return JsonResponse({"retcode": errcode.USERADDSUCCESS, "msg": "", "data": user.admin.toJson_User(u)})


@csrf_exempt
def userdel(request: HttpRequest):
    datas = json.loads(request.body)
    id = datas.get("id")
    username = datas.get("username")
    if id is not None:
        u = User.objects.get(id=id)
    else:
        u = User.objects.get(username=username)
    if not u:
        JsonResponse({"retcode": errcode.USERDELSUCCESS, "msg": "no this user", "data": {}})
    taskcount = task.models.Task.objects.filter(user=u).exclude(status=task.models.TASK_CANCELED).exclude(
        status=task.models.TASK_COMPLETE).count()
    if taskcount > 0:
        return JsonResponse(
            {"retcode": errcode.USERDELFAILED, "msg": errcode.USERDEL_MSG_THEREATASKRUNNING, "data": {}})
    if id is not None:
        User.objects.delete(id=id)
    else:
        User.objects.delete(username=username)
    return JsonResponse({"retcode": 0, "msg": "success", "data": {}})
