"""clouddog URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
#from filebrowser.sites import site
import clouddog
import parkarea
import task
import vehicle
import user.urls
import chargearea.views
import parkarea.views
import chargedog.views
import task.views
import user.views



urlpatterns = [
    path('admin/', admin.site.urls),
    path('chargearea/', chargearea.views.chargearea),
    path('parkarea/', parkarea.views.parkarea),
    path('chargedog/', chargedog.views.chargedog),
    path('task/', task.views.task),
    path('taskdetail/', task.views.taskdetail),
    path('dogdetail/', chargedog.views.dogdetail),
    path('createtask/', task.views.trycreate),
    path('logs/', chargedog.views.showlogs),
    path('user/', include('user.urls')),
    #path('grappelli/', include('grappelli.urls')),
    path('nearinfo/', user.views.nearinfo),
    path('clearall/', user.views.clearall),

    #path('chargedog/', chargedog.urls),
    #path('vehicle/', vehicle.urls),
    #path('task/', task.urls),
    #path('parkarea/', parkarea.urls),
]
