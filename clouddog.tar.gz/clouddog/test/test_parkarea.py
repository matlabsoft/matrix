import json
from unittest import TestCase
import unittest
import requests
from const import errcode

REQUEST_URL = "http://192.168.0.48:8000/parkarea/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}


class TestParkarea(TestCase):
    def test_parkarea(self):
        #增加
        requestDict = {"latitude":120.123, "logitude":65.123}
        rsp = requests.post(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newarea = datas.get("data")

        #查询所有
        rsp = requests.get(REQUEST_URL, data=json.dumps({}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertIn(newarea.get("id"), [area.get("id") for area in datas.get("data")])

        #根据经纬度查询单条
        rsp = requests.get(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertEqual(newarea.get("id"), datas.get("data").get("id"))

        #修改经纬度
        requestDict = {"id": newarea.get("id"), "latitude": 66.66, "logitude": 77.77}
        rsp = requests.put(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

        #根据ID查询
        rsp = requests.get(REQUEST_URL, data=json.dumps({"id": newarea.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertEqual(newarea.get("id"), datas.get("data").get("id"))
        self.assertEqual(requestDict.get("latitude"), datas.get("data").get("latitude"))
        self.assertEqual(requestDict.get("logitude"), datas.get("data").get("logitude"))

        #删除数据
        rsp = requests.delete(REQUEST_URL, data=json.dumps({"id": newarea.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

        rsp = requests.get(REQUEST_URL, data=json.dumps({"id": newarea.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertEqual(None, datas.get("data"))


if __name__ == '__main__':
    unittest.main()
