import json
from unittest import TestCase
import unittest
import requests

REQUEST_URL = "http://139.9.124.211:8000/user/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}


class TestUser(TestCase):
    def deleteuser(self):
        requests.post(REQUEST_URL + "delete/", data=json.dumps({'username':'testuser'})
    def test_delete(self):
        requestDict = {'username': "testuser"}
    def test_register(self):
        requestDict = {'username': "testuser", "userpwd": "Changeme_123"}
        rsp = requests.post(REQUEST_URL + "register/", data=json.dumps(requestDict), headers=HEADER)
        print(rsp.text)

if __name__=='__main__':
    #body = b'username=testuser&userpwd=Changeme_123'
    #print(json.loads(body, encoding="utf-8"))
    unittest.main()