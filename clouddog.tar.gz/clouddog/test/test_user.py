import json
from unittest import TestCase
import unittest
import requests
from const import errcode

REQUEST_URL = "http://192.168.0.48:8000/user/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}


class TestUser(TestCase):
    def deleteuser(self):
        requestDict = {'username': "testuser"}
        requests.delete(REQUEST_URL + "delete/", data=json.dumps(requestDict), headers=HEADER)

    def createuser(self):
        requestDict = {'username': "testuser", "userpwd": "Changeme_123"}
        rsp = requests.post(REQUEST_URL + "register/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        return datas.get("data")

    def test_register(self):
        self.deleteuser()

        self.createuser()

        #用户已经存在的情况下注册失败
        requestDict = {'username': "testuser", "userpwd": "Changeme_123"}
        rsp = requests.post(REQUEST_URL + "register/", data=json.dumps(requestDict), headers=HEADER)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDFAILED)
        self.deleteuser()

    def test_login(self):
        self.deleteuser()
        requestDict = {'username': "testuser", "userpwd": "Changeme_123"}
        # 用户不存在时登陆失败
        rsp = requests.post(REQUEST_URL + "login/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.LOGINFAILED)

        # 正常登陆成功
        self.createuser()

        rsp = requests.post(REQUEST_URL + "login/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.LOGINSUCCESS)

        # 密码不正确时登陆失败
        requestDict = {'username': "testuser", "userpwd": "ErrorPassword"}
        rsp = requests.post(REQUEST_URL + "login/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.LOGINFAILED)

        self.deleteuser()

    def test_modmoney(self):
        self.deleteuser()
        self.createuser()
        requestDict = {'username': "testuser", "money": 110.0}
        # 用户不存在时登陆失败
        rsp = requests.put(REQUEST_URL + "put/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.SUCCESS)

        userdata = self.getUser(username="testuser")
        self.assertEqual(110.0, userdata.get("money"))
        self.deleteuser()

    def getUser(self, id=None, username=None):
        rsp = requests.get(REQUEST_URL + "get/", data=json.dumps({"id": id, "username":username}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        return datas.get("data")

    def test_getinfo(self):
        self.deleteuser()
        #正常注册成功
        userdatas = self.createuser()

        #获取用户信息
        self.getUser(username="testuser")
        self.getUser(id=userdatas.get("id"))

        self.deleteuser()

    def test_modifypwd_with_correctpwd(self):
        self.deleteuser()
        self.createuser()

        requestDict = {'username': "testuser", "useroldpwd":"Changeme_123", "userpwd": "NewChangeme_123"}
        rsp = requests.put(REQUEST_URL + "changepwd/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERCHPWDSUCCESS)

        rsp = requests.post(REQUEST_URL + "login/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.LOGINSUCCESS)

        self.deleteuser()

    def test_modifypwd_with_errorpwd(self):
        self.deleteuser()
        self.createuser()

        requestDict = {'username': "testuser", "useroldpwd": "ErrorPassword", "userpwd": "NewChangeme_123"}
        rsp = requests.put(REQUEST_URL + "changepwd/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERCHPWDFAILED)

        rsp = requests.post(REQUEST_URL + "login/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.LOGINFAILED)

        self.deleteuser()

    def test_addvehicle(self):
        '''
        测试给用户增加车，1个用户可以拥有多辆车，一辆车也可以数用多个用户， 车辆主键为车牌
        '''
        self.deleteuser()
        self.createuser()

        vehicleDict = {'username': "testuser", "producername":"福特", "productname":"蒙迪欧", "carnumber":"沪A8888", "latitude":120.123, "logitude":65.123}
        rsp = requests.post(REQUEST_URL + "addvehicle/", data=json.dumps(vehicleDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERDELSUCCESS)
        self.assertEqual("沪A8888", datas.get("data")[0].get("carnumber"))

        # 查看用户的车辆详细信息
        requestDict = {'username': "testuser"}
        rsp = requests.get(REQUEST_URL + "listvehicle/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERLISTVEHICLESUCCESS)
        # 如果存在多辆车， 这里datas.get("data")就可以[0],[1],...
        self.assertEqual("沪A8888", datas.get("data")[0].get("carnumber"))

        self.deleteuser()
    def test_delvehicle(self):
        self.deleteuser()
        self.createuser()

        vehicleDict = {'username': "testuser", "producername":"福特", "productname":"蒙迪欧", "carnumber":"沪A8888", "latitude":120.123, "logitude":65.123}
        rsp = requests.post(REQUEST_URL + "addvehicle/", data=json.dumps(vehicleDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERDELSUCCESS)
        self.assertEqual("沪A8888", datas.get("data")[0].get("carnumber"))

        # 查看用户的车辆详细信息
        requestDict = {'id': datas.get("data")[0].get("id")}
        rsp = requests.delete(REQUEST_URL + "delvehicle/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.SUCCESS)

        self.deleteuser()




if __name__ == '__main__':
    unittest.main()
