from unittest import TestCase
import json
import unittest
import requests
from const import errcode

REQUEST_URL = "http://192.168.0.48:8000/nearinfo/"
CLEAR_URL = "http://192.168.0.48:8000/clearall/"
TASKDETAIL_URL = "http://192.168.0.48:8000/taskdetail/"
USER_URL = "http://192.168.0.48:8000/user/"
DOG_URL = "http://192.168.0.48:8000/chargedog/"
AREA_URL = "http://192.168.0.48:8000/chargearea/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}


class TestChargedog(TestCase):

    def setUp(self):
        super().setUp()
        requests.delete(CLEAR_URL, data=json.dumps({}), headers=HEADER)
        self.dogdata = self.add_chargedog()
        self.areadata = self.add_chargearea()
        (self.userdata, self.vehicledata) = self.add_user()

    def tearDown(self):
        self.del_chargearea()
        self.del_chargedog()
        self.del_user()
        super().tearDown()

    def add_chargedog(self):
        # 增加充电狗，关键字是名字，其余属性可以不填
        requestDict = {"macaddr":"00-08-61-8D-FE-94", "name": "Manka-1", "latitude": 120.123, "logitude": 65.123,
                       "mainstatus": "IDLE", "workmode": "IDLE",
                       "remotecontrol": False, "remainpower": 100.0, "detailmsg": ""}
        rsp = requests.post(DOG_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newdog = datas.get("data")
        return newdog

    def del_chargedog(self):
        rsp = requests.delete(DOG_URL, data=json.dumps({"id": self.dogdata.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

    def add_chargearea(self):
        requestDict = {"latitude": 120.123, "logitude": 65.123}
        rsp = requests.post(AREA_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newarea = datas.get("data")
        return newarea

    def del_chargearea(self):
        rsp = requests.delete(AREA_URL, data=json.dumps({"id": self.areadata.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

    def add_user(self):
        requestDict = {'username': "testuser"}
        requests.post(USER_URL + "delete/", data=json.dumps(requestDict), headers=HEADER)
        # 正常注册成功
        requestDict = {'username': "testuser", "userpwd": "Changeme_123", "money": 100}
        rsp = requests.post(USER_URL + "register/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newuser = datas.get("data")

        vehicleDict = {'username': "testuser", "producername": "福特", "productname": "蒙迪欧", "carnumber": "沪A8888",
                       "latitude": 120.123, "logitude": 65.123}
        rsp = requests.post(USER_URL + "addvehicle/", data=json.dumps(vehicleDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERDELSUCCESS)
        self.assertEqual("沪A8888", datas.get("data")[0].get("carnumber"))
        return (newuser, datas.get("data")[0])

    def del_user(self):
        requestDict = {'username': self.userdata.get("username")}
        requests.delete(USER_URL + "delete/", data=json.dumps(requestDict), headers=HEADER)

    def getUser(self, id=None, username=None):
        rsp = requests.get(USER_URL + "get/", data=json.dumps({"id": id, "username": username}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        return datas.get("data")

    def test_nearinfo(self):
        #distance 的单位是 度， 这里是(latitude, logitude)圆心，distance为半径， 查询附近的充电狗河充电点
        rsp = requests.get(REQUEST_URL, data=json.dumps({"latitude": 127.1, "logitude": 63.7, "distance":100}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        self.assertEqual(list(datas.get("data").keys()), ["areas", "dogs"])
        '''
        {'areas': [{'createtime': '2019-10-16T12:25:23.878Z',
            'id': 35,
            'latitude': 120.123,
            'logitude': 65.123}],
 'dogs': [{'command': '',
           'detailmsg': '',
           'dogtype': 'Pythagoras',
           'dogversion': 'V1.0',
           'id': 36,
           'latitude': 120.123,
           'logitude': 65.123,
           'mainstatus': 'IDLE',
           'macaddr':'00-08-61-8D-FE-94', 
           'name': 'Manka-1',
           'remainpower': 100.0,
           'remotecontrol': False,
           'workmode': 'IDLE'}]}
           '''



if __name__ == '__main__':
    unittest.main()
