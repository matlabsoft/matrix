import json
from unittest import TestCase
import unittest
import requests
from const import errcode

REQUEST_URL = "http://192.168.0.48:8000/initareas/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}

requests.post(REQUEST_URL, data=json.dumps({}), headers=HEADER)
