from unittest import TestCase
import json
import unittest
import requests
from const import errcode

REQUEST_URL = "http://192.168.0.48:8000/task/"
CLEAR_URL = "http://192.168.0.48:8000/clearall/"
CREATETASK_URL = "http://192.168.0.48:8000/createtask/"
TASKDETAIL_URL = "http://192.168.0.48:8000/taskdetail/"
DOGDETAIL_URL= "http://192.168.0.48:8000/dogdetail/"
USER_URL = "http://192.168.0.48:8000/user/"
DOG_URL = "http://192.168.0.48:8000/chargedog/"
AREA_URL = "http://192.168.0.48:8000/chargearea/"
HEADER = {'Content-Type': 'application/json; charset=utf-8'}


class TestChargedog(TestCase):

    def setUp(self):
        super().setUp()
        requests.delete(CLEAR_URL, data=json.dumps({}), headers=HEADER)
        self.dogdata = self.add_chargedog()
        self.areadata = self.add_chargearea()
        (self.userdata, self.vehicledata) = self.add_user()

    def tearDown(self):
        self.del_chargearea()
        self.del_chargedog()
        self.del_user()
        requests.delete(CLEAR_URL, data=json.dumps({}), headers=HEADER)
        super().tearDown()

    def add_chargedog(self):
        # 增加充电狗，关键字是名字，其余属性可以不填
        requestDict = {"macaddr":"00-08-61-8D-FE-94", "name": "Manka-1", "latitude": 120.123, "logitude": 65.123,
                       "mainstatus": "IDLE", "workmode": "IDLE",
                       "remotecontrol": False, "remainpower": 100.0, "detailmsg": ""}
        rsp = requests.post(DOG_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newdog = datas.get("data")
        return newdog

    def del_chargedog(self):
        rsp = requests.delete(DOG_URL, data=json.dumps({"id": self.dogdata.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

    def add_chargearea(self):
        requestDict = {"latitude": 120.123, "logitude": 65.123}
        rsp = requests.post(AREA_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newarea = datas.get("data")
        return newarea

    def del_chargearea(self):
        rsp = requests.delete(AREA_URL, data=json.dumps({"id": self.areadata.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

    def add_user(self):
        requestDict = {'username': "testuser"}
        requests.post(USER_URL + "delete/", data=json.dumps(requestDict), headers=HEADER)
        # 正常注册成功
        requestDict = {'username': "testuser", "userpwd": "Changeme_123", "money": 100}
        rsp = requests.post(USER_URL + "register/", data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newuser = datas.get("data")

        vehicleDict = {'username': "testuser", "producername": "福特", "productname": "蒙迪欧", "carnumber": "沪A8888",
                       "latitude": 120.123, "logitude": 65.123}
        rsp = requests.post(USER_URL + "addvehicle/", data=json.dumps(vehicleDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERDELSUCCESS)
        self.assertEqual("沪A8888", datas.get("data")[0].get("carnumber"))
        return (newuser, datas.get("data")[0])

    def del_user(self):
        requestDict = {'username': self.userdata.get("username")}
        requests.delete(USER_URL + "delete/", data=json.dumps(requestDict), headers=HEADER)

    def getUser(self, id=None, username=None):
        rsp = requests.get(USER_URL + "get/", data=json.dumps({"id": id, "username": username}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        return datas.get("data")

    def test_task(self):
        # 增加任务，关键字是名字，其余属性可以不填
        requestDict = {"userid": self.userdata.get("id"), "dogid": self.dogdata.get("id"),
                       "areaid": self.areadata.get("id"), "vehicleid": self.vehicledata.get("id"), "needpower": 10.0}
        rsp = requests.post(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newtask = datas.get("data")

        # 查询所有
        # topn=5代表只查询最近5条，如果不设置topn最多查询最近100条
        rsp = requests.get(REQUEST_URL, data=json.dumps({"topn": 5}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertIn(newtask.get("id"), [area.get("id") for area in datas.get("data")])

        # 根据用户ID来查询
        rsp = requests.get(REQUEST_URL, data=json.dumps({"userid": self.userdata.get("id"), "topn": 1}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertIn(newtask.get("id"), [area.get("id") for area in datas.get("data")])

        # query by charge dog
        rsp = requests.get(REQUEST_URL, data=json.dumps({"dogid": self.dogdata.get("id"), "topn": 1}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertIn(newtask.get("id"), [area.get("id") for area in datas.get("data")])

        # 修改路径信息[[latitude1, logitude1], [latitude2, logitude2], [latitude3, logitude3], ...]
        requestDict = {"id": newtask.get("id"), "roadline": [[127.1, 63.1], [127.2, 63.2], []]}
        rsp = requests.put(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

        # 修改任务状态, 当FINISH或CANCELED会联动endtime和用户的money
        requestDict = {"id": newtask.get("id"), "status": "FINISH", "powerfee": 5}
        rsp = requests.put(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        newuserdatas = self.getUser(id=self.userdata.get("id"))
        self.assertEqual(newuserdatas.get("money") + requestDict.get("powerfee"), self.userdata.get("money"))

        # 根据ID查询
        rsp = requests.get(REQUEST_URL, data=json.dumps({"id": newtask.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertEqual(newtask.get("id"), datas.get("data").get("id"))

        # 删除数据,
        rsp = requests.delete(REQUEST_URL, data=json.dumps({"id": newtask.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))

        rsp = requests.get(REQUEST_URL, data=json.dumps({"id": newtask.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertEqual(None, datas.get("data"))

    def test_trycreate_normal(self):
        requestDict = {"userid": self.userdata.get("id"), "areaid": self.areadata.get("id"),
                "vehicleid": self.vehicledata.get("id"), "needpower": 10.0}
        rsp = requests.post(CREATETASK_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        '''{'retcode': 'SUCCESS', 'msg': '', 'data': {'id': 6, 'user': 66, 'chargedog': 136, 'chargearea': 133, 'vehicle': 93, 'starttime': '2019-10-18T04:48:18.046Z', 'endtime': None, 'status': 'INIT', 'needpower': 10.0, 'haschargedpower': 0.0, 'leftpowerofcar': -1.0, 'leftchargetime': 0.0, 'currentflow': 0.0, 'powerfee': 0.0, 'roadline': '[]'}}'''
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newtask = datas.get("data")
        self.assertEqual(newtask.get('chargearea'), self.areadata.get("id"))
        self.assertEqual(newtask.get('user'), self.userdata.get("id"))
        pass

    def test_trycreate_nodog(self):
        self.del_chargedog()
        requestDict = {"userid": self.userdata.get("id"), "areaid": self.areadata.get("id"),
                "vehicleid": self.vehicledata.get("id"), "needpower": 10.0}
        rsp = requests.post(CREATETASK_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        '''{'retcode': 'FAILED', 'msg': 'NO_AVAIABLE_CHARGEDOG', 'data': None}'''
        self.assertEqual(datas.get("retcode"), errcode.FAILED)
        self.assertEqual(datas.get("msg"), 'NO_AVAIABLE_CHARGEDOG')
        pass

    def test_dogdetail(self):
        # 增加任务，关键字是名字，其余属性可以不填
        requestDict = {"userid": self.userdata.get("id"), "dogid": self.dogdata.get("id"),
                       "areaid": self.areadata.get("id"), "vehicleid": self.vehicledata.get("id"), "needpower": 10.0}
        rsp = requests.post(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newtask = datas.get("data")


        rsp = requests.get(DOGDETAIL_URL, data=json.dumps({"id": self.dogdata.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertListEqual(['dog', 'task'], list(datas.get("data").keys()))
        '''
{'dog': {'id': 23, 'macaddr': '00-08-61-8D-FE-94', 'name': 'Manka-1', 'dogtype': 'Pythagoras', 'dogversion': 'V1.0', 'latitude': 120.123, 'logitude': 65.123, 'remainpower': 100.0, 'mainstatus': 'IDLE', 'workmode': 'IDLE', 'remotecontrol': False, 'command': '', 'detailmsg': ''}, 'task': {'id': 5, 'user': 57, 'chargedog': 23, 'chargearea': 29, 'vehicle': 29, 'starttime': '2019-10-21T03:53:35.582Z', 'endtime': None, 'status': 'INIT', 'needpower': 10.0, 'haschargedpower': 0.0, 'leftpowerofcar': -1.0, 'leftchargetime': 0.0, 'currentflow': 0.0, 'powerfee': 0.0, 'roadline': '[]'}}'''

    def test_taskdetail(self):
        # 增加任务，关键字是名字，其余属性可以不填
        requestDict = {"userid": self.userdata.get("id"), "dogid": self.dogdata.get("id"),
                       "areaid": self.areadata.get("id"), "vehicleid": self.vehicledata.get("id"), "needpower": 10.0}
        rsp = requests.post(REQUEST_URL, data=json.dumps(requestDict), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(datas.get("retcode"), errcode.USERADDSUCCESS)
        newtask = datas.get("data")

        # 根据task id来查询
        rsp = requests.get(TASKDETAIL_URL, data=json.dumps({"id": newtask.get("id")}), headers=HEADER)
        self.assertEqual(rsp.status_code, 200)
        datas = json.loads(rsp.text)
        self.assertEqual(errcode.SUCCESS, datas.get("retcode"))
        self.assertListEqual(['task', 'user', 'chargedog', 'chargearea', 'vehicle'], list(datas.get("data").keys()))
        '''
        {'chargearea': {'createtime': '2019-10-16T11:52:55.809Z',
                'id': 17,
                'latitude': 120.123,
                'logitude': 65.123},
 'chargedog': {'command': '',
               'detailmsg': '',
               'dogtype': 'Pythagoras',
               'dogversion': 'V1.0',
               'id': 17,
               'latitude': 120.123,
               'logitude': 65.123,
               'mainstatus': 'IDLE',
               'macaddr':'00-08-61-8D-FE-94', 
               'name': 'Manka-1',
               'remainpower': 100.0,
               'remotecontrol': False,
               'workmode': 'IDLE'},
 'task': {'chargearea': 17,
          'chargedog': 17,
          'currentflow': 0.0,
          'endtime': None,
          'haschargedpower': 0.0,
          'id': 11,
          'leftchargetime': 0.0,
          'leftpowerofcar': -1.0,
          'needpower': 10.0,
          'powerfee': 0.0,
          'roadline': '[]',
          'starttime': '2019-10-16T11:52:56.547Z',
          'status': 'INIT',
          'user': 23,
          'vehicle': 1},
 'user': {'createtime': '2019-10-16T11:52:56.179Z',
          'id': 23,
          'lastlogin': '2019-10-16T11:52:56.179Z',
          'money': 100.0,
          'username': 'testuser'},
 'vehicle': {'carnumber': '沪A8888',
             'id': 1,
             'isdelete': False,
             'latitude': 120.123,
             'logitude': 65.123,
             'producername': '福特',
             'productname': '蒙迪欧'}}
        '''



if __name__ == '__main__':
    unittest.main()
