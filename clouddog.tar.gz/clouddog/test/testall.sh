#!/bin/bash
echo "python test_chargearea.py"
python test_chargearea.py
echo "python test_chargedog.py"
python test_chargedog.py
echo "python test_nearinfo.py"
python test_nearinfo.py
echo "python test_task.py"
python test_task.py
echo "python test_user.py"
python test_user.py
