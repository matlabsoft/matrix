#!/usr/bin/python3
from daemon.runner import DaemonRunner
import os

logsdir="/export/home/logs"
class MyApp(object):
    def __init__(self):
        self.stdin_path = "/dev/null"
        self.stdout_path = os.path.join(logsdir, "stdout.log")
        self.stderr_path =  os.path.join(logsdir, "stderr.log")
        self.pidfile_path =  os.path.join(logsdir, "pid.pid")
        self.pidfile_timeout = 5

    def run(self):
        os.system("python /export/home/clouddog/manage.py runserver 192.168.0.48:8000")

if __name__ == '__main__':
    run = DaemonRunner(MyApp())
    run.do_action()

