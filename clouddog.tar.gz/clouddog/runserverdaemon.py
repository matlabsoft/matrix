#!/usr/bin/python3
import os
import sys
import logging

def deamonize(stdout='/dev/null', stderr='/dev/null', stdin='/dev/null'):
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as e:
        sys.stderr.write("fork the first time failed:%s\n"%str(e))
        sys.exit(101)
    os.chdir("/")
    os.umask(0)
    os.setsid()

    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as e:
        sys.stderr.write("for the second time failed:%s\n"%str(e))
        sys.exit(102)

    for f in sys.stdout, sys.stderr:
        f.flush()

    si = open(stdin, 'r')
    so = open("/var/log/clouddog/main.log", 'ab', 0)
    se = open("/var/log/clouddog/main.log", 'ab', 0)

    os.dup2(si.fileno(), sys.stdin.fileno())
    os.dup2(so.fileno(), sys.stdout.fileno())
    os.dup2(se.fileno(), sys.stderr.fileno())

if __name__ == '__main__':
    deamonize()
    cmds = " ".join(sys.argv[1:])
    os.system(cmds)

